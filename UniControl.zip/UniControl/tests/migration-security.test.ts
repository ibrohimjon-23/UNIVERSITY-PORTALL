import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import path from "node:path";

const sql = readFileSync(path.resolve(__dirname, "../supabase/migrations/0001_init.sql"), "utf-8");

describe("core schema security invariants", () => {
  it("enables row level security on every sensitive table", () => {
    const tables = [
      "groups",
      "profiles",
      "schedules",
      "attendance_sessions",
      "attendance_records",
      "assignments",
      "assignment_submissions",
      "notifications",
      "notification_reads",
      "audit_logs",
      "university_settings",
    ];
    for (const table of tables) {
      expect(sql).toMatch(new RegExp(`alter table public\\.${table} enable row level security`));
    }
  });

  it("fn_submit_attendance validates every required condition before recording attendance", () => {
    const start = sql.indexOf("create or replace function public.fn_submit_attendance");
    const end = sql.indexOf("revoke all on function public.fn_submit_attendance");
    const body = sql.slice(start, end);

    const requiredChecks = [
      "v_role is null or v_role <> 'student'", // must be a student
      "not v_active", // must be active
      "v_group_id is null", // must belong to a group
      "v_session.group_id <> v_group_id", // session must match student's group
      "v_session.status <> 'active'", // session must be active
      "now() < v_session.start_time or now() > v_session.end_time", // within time window
      "p_qr_token is null or p_qr_token <> v_session.qr_token", // QR must match
      "now() > v_session.qr_expires_at", // QR must not be expired
      "p_latitude < -90 or p_latitude > 90", // latitude bounds
      "p_longitude < -180 or p_longitude > 180", // longitude bounds
      "v_already_exists", // no duplicate submissions
      "v_distance > v_settings.attendance_radius_m", // geofence enforced server-side
    ];

    for (const check of requiredChecks) {
      expect(body).toContain(check);
    }
  });

  it("attendance_records has a unique constraint preventing duplicate check-ins", () => {
    expect(sql).toMatch(/unique \(student_id, attendance_session_id\)/);
  });

  it("leaders are confined to their own group by leads_group() in every session/assignment policy", () => {
    const leaderPolicies = sql.match(/create policy [a-z_]*leader[a-z_]* on public\.\w+[\s\S]*?;/g) ?? [];
    const sessionOrAssignmentPolicies = leaderPolicies.filter(
      (p) => p.includes("attendance_sessions") || p.includes("assignments"),
    );
    expect(sessionOrAssignmentPolicies.length).toBeGreaterThan(0);
    for (const policy of sessionOrAssignmentPolicies) {
      expect(policy).toContain("leads_group");
    }
  });

  it("fn_assign_leader and fn_rotate_qr are restricted to admins/leaders, not public", () => {
    expect(sql).toContain("revoke all on function public.fn_assign_leader from public");
    expect(sql).toContain("revoke all on function public.fn_rotate_qr from public");
  });
});
