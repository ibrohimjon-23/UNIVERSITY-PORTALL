import { describe, expect, it } from "vitest";
import { loginSchema } from "@/validators/auth";
import { submitAttendanceSchema, createAttendanceSessionSchema } from "@/validators/attendance";
import { groupSchema } from "@/validators/group";
import { createStudentSchema } from "@/validators/profile";
import { scheduleSchema } from "@/validators/schedule";

describe("loginSchema", () => {
  it("accepts a valid username and numeric PIN", () => {
    expect(loginSchema.safeParse({ username: "john.smith", pin: "123456" }).success).toBe(true);
  });

  it("rejects a PIN that is too short", () => {
    expect(loginSchema.safeParse({ username: "john.smith", pin: "12" }).success).toBe(false);
  });

  it("rejects a non-numeric PIN", () => {
    expect(loginSchema.safeParse({ username: "john.smith", pin: "abcdef" }).success).toBe(false);
  });

  it("rejects a username with invalid characters", () => {
    expect(loginSchema.safeParse({ username: "john smith!", pin: "123456" }).success).toBe(false);
  });
});

describe("submitAttendanceSchema", () => {
  const base = { session_id: "11111111-1111-1111-1111-111111111111", qr_token: "a".repeat(20) };

  it("accepts valid coordinates within range", () => {
    expect(submitAttendanceSchema.safeParse({ ...base, latitude: 40.78, longitude: 72.35, accuracy: 15 }).success).toBe(true);
  });

  it("rejects latitude outside -90..90", () => {
    expect(submitAttendanceSchema.safeParse({ ...base, latitude: 120, longitude: 72.35 }).success).toBe(false);
  });

  it("rejects longitude outside -180..180", () => {
    expect(submitAttendanceSchema.safeParse({ ...base, latitude: 40.78, longitude: 200 }).success).toBe(false);
  });

  it("rejects a non-UUID session id", () => {
    expect(submitAttendanceSchema.safeParse({ ...base, session_id: "not-a-uuid", latitude: 40.78, longitude: 72.35 }).success).toBe(
      false,
    );
  });
});

describe("createAttendanceSessionSchema", () => {
  it("caps duration at 240 minutes", () => {
    expect(
      createAttendanceSessionSchema.safeParse({
        group_id: "11111111-1111-1111-1111-111111111111",
        subject_id: "11111111-1111-1111-1111-111111111111",
        duration_minutes: 500,
      }).success,
    ).toBe(false);
  });
});

describe("groupSchema", () => {
  it("rejects a course number outside 1..8", () => {
    expect(groupSchema.safeParse({ group_name: "CS-1", faculty: "CS", course: 12, year: 2025 }).success).toBe(false);
  });
});

describe("createStudentSchema", () => {
  it("requires a valid group id", () => {
    const result = createStudentSchema.safeParse({
      first_name: "A",
      last_name: "B",
      username: "a.b",
      pin: "1234",
      student_id: "S1",
      group_id: "not-a-uuid",
    });
    expect(result.success).toBe(false);
  });
});

describe("scheduleSchema", () => {
  it("rejects an end time before the start time", () => {
    const result = scheduleSchema.safeParse({
      group_id: "11111111-1111-1111-1111-111111111111",
      subject_id: "11111111-1111-1111-1111-111111111111",
      room: "205",
      day_of_week: 1,
      start_time: "10:00",
      end_time: "09:00",
    });
    expect(result.success).toBe(false);
  });
});
