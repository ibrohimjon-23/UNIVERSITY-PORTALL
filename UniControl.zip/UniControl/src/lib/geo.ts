/**
 * Client-side helpers for the Geolocation API and distance display.
 * These are for UX only (showing an estimated distance/status to the
 * student before submitting). The authoritative check that actually
 * grants/denies attendance runs server-side in Postgres
 * (fn_submit_attendance / fn_haversine_meters) — the frontend value is
 * never trusted for the security decision.
 */

export interface GeoPosition {
  latitude: number;
  longitude: number;
  accuracy: number | null;
}

export class GeolocationUnsupportedError extends Error {}
export class GeolocationDeniedError extends Error {}
export class GeolocationTimeoutError extends Error {}

export function getCurrentPosition(options?: PositionOptions): Promise<GeoPosition> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      reject(new GeolocationUnsupportedError("Geolocation is not supported on this device."));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy ?? null,
        });
      },
      (error) => {
        if (error.code === error.PERMISSION_DENIED) {
          reject(new GeolocationDeniedError("Location permission was denied."));
        } else if (error.code === error.TIMEOUT) {
          reject(new GeolocationTimeoutError("Getting your location took too long. Try again."));
        } else {
          reject(new Error("Could not determine your location."));
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0, ...options },
    );
  });
}

/** Haversine distance in meters — mirrors the server-side Postgres function for UI display only. */
export function haversineMeters(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371000;
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const dPhi = ((lat2 - lat1) * Math.PI) / 180;
  const dLambda = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dPhi / 2) ** 2 + Math.cos(phi1) * Math.cos(phi2) * Math.sin(dLambda / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
