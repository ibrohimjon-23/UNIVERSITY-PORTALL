import QRCode from "qrcode";

export interface AttendanceQrPayload {
  sessionId: string;
  token: string;
}

export function encodeAttendanceQr(payload: AttendanceQrPayload): string {
  return JSON.stringify(payload);
}

export function decodeAttendanceQr(raw: string): AttendanceQrPayload | null {
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed?.sessionId === "string" && typeof parsed?.token === "string") {
      return { sessionId: parsed.sessionId, token: parsed.token };
    }
    return null;
  } catch {
    return null;
  }
}

/** Renders the session+token pair as a scannable QR code data URL (PNG). */
export async function generateQrDataUrl(payload: AttendanceQrPayload): Promise<string> {
  return QRCode.toDataURL(encodeAttendanceQr(payload), {
    errorCorrectionLevel: "M",
    margin: 1,
    width: 320,
  });
}
