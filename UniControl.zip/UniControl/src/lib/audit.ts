import "server-only";
import { headers } from "next/headers";
import { createClient } from "@/lib/supabase/server";

interface AuditParams {
  actorId: string;
  action: string;
  entityType: string;
  entityId?: string | null;
  oldData?: Record<string, unknown> | null;
  newData?: Record<string, unknown> | null;
}

/**
 * Writes one row to audit_logs. Called explicitly at the end of every
 * sensitive server action (create/update/delete on groups, students,
 * leaders, schedules, assignments, notifications, settings).
 */
export async function logAudit(params: AuditParams): Promise<void> {
  const supabase = await createClient();
  const hdrs = await headers();
  const ipAddress = hdrs.get("x-forwarded-for")?.split(",")[0]?.trim() ?? hdrs.get("x-real-ip") ?? null;
  const userAgent = hdrs.get("user-agent") ?? null;

  await supabase.from("audit_logs").insert({
    actor_id: params.actorId,
    action: params.action,
    entity_type: params.entityType,
    entity_id: params.entityId ?? null,
    old_data: params.oldData ?? null,
    new_data: params.newData ?? null,
    ip_address: ipAddress,
    user_agent: userAgent,
  });
}
