import "server-only";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile, UserRole } from "@/types/database";

/**
 * UniControl logs users in with a username + PIN, but Supabase Auth is
 * email/password based. We map every username to a synthetic, non-routable
 * email address on a fixed internal domain and use the PIN as the password.
 * Supabase's GoTrue service performs the actual secure hashing (bcrypt) and
 * session/JWT management — we never touch or store raw PINs ourselves.
 */
export function usernameToAuthEmail(username: string): string {
  const domain = process.env.AUTH_USERNAME_DOMAIN || "unicontrol.internal";
  return `${username.trim().toLowerCase()}@${domain}`;
}

export async function getCurrentProfile(): Promise<Profile | null> {
  const supabase = await createClient();
  const { data: userData } = await supabase.auth.getUser();
  if (!userData?.user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userData.user.id)
    .maybeSingle();

  return (profile as Profile) ?? null;
}

export async function requireProfile(): Promise<Profile> {
  const profile = await getCurrentProfile();
  if (!profile) redirect("/login");
  if (!profile.is_active) redirect("/login?error=inactive");
  return profile;
}

export async function requireRole(...roles: UserRole[]): Promise<Profile> {
  const profile = await requireProfile();
  if (!roles.includes(profile.role)) {
    redirect(`/${profile.role}`);
  }
  return profile;
}

export function dashboardPathForRole(role: UserRole): string {
  switch (role) {
    case "admin":
      return "/admin";
    case "leader":
      return "/leader";
    case "student":
      return "/student";
  }
}
