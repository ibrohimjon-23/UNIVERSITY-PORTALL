import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";
import type { CookieOptions } from "@supabase/ssr";

const PUBLIC_PATHS = ["/login", "/api/health"];

function roleHomePrefix(role: string | undefined): string {
  if (role === "admin") return "/admin";
  if (role === "leader") return "/leader";
  if (role === "student") return "/student";
  return "/login";
}

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) => {
            response.cookies.set(name, value, options);
          });
        },
      },
    },
  );

  const { data: userData } = await supabase.auth.getUser();
  const path = request.nextUrl.pathname;
  const isPublic = PUBLIC_PATHS.some((p) => path === p || path.startsWith(p + "/"));

  if (!userData?.user) {
    if (!isPublic && path !== "/") {
      const loginUrl = new URL("/login", request.url);
      return NextResponse.redirect(loginUrl);
    }
    return response;
  }

  // Authenticated: fetch role once to enforce section boundaries.
  const { data: profile } = await supabase
    .from("profiles")
    .select("role, is_active")
    .eq("id", userData.user.id)
    .maybeSingle();

  if (!profile || !profile.is_active) {
    const loginUrl = new URL("/login?error=inactive", request.url);
    return NextResponse.redirect(loginUrl);
  }

  const homePrefix = roleHomePrefix(profile.role);

  if (path === "/" || path === "/login") {
    return NextResponse.redirect(new URL(homePrefix, request.url));
  }

  const isAdminPath = path.startsWith("/admin");
  const isLeaderPath = path.startsWith("/leader");
  const isStudentPath = path.startsWith("/student");

  if ((isAdminPath && homePrefix !== "/admin") ||
      (isLeaderPath && homePrefix !== "/leader") ||
      (isStudentPath && homePrefix !== "/student")) {
    return NextResponse.redirect(new URL(homePrefix, request.url));
  }

  return response;
}
