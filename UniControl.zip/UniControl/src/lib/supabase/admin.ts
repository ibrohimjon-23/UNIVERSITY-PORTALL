import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * Service-role Supabase client. Bypasses Row Level Security entirely.
 * NEVER import this from a Client Component. Used only for privileged
 * operations that the anon/user JWT cannot perform, such as creating
 * auth.users accounts for new students/leaders from the Admin/Leader UI.
 *
 * Not parameterized with our Database type — see the comment in
 * `lib/supabase/client.ts` for why.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error("Missing Supabase service role configuration.");
  }

  return createSupabaseClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
