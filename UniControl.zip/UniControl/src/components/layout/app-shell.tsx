import { SidebarNav } from "@/components/layout/sidebar-nav";
import { Navbar } from "@/components/layout/navbar";
import { NAV_ITEMS } from "@/components/layout/nav-config";
import { getUnreadNotificationCount } from "@/features/notifications/queries";
import { formatFullName } from "@/lib/utils";
import type { Profile } from "@/types/database";

export async function AppShell({ profile, children }: { profile: Profile; children: React.ReactNode }) {
  const navItems = NAV_ITEMS[profile.role];
  const unreadCount = await getUnreadNotificationCount();
  const basePath = `/${profile.role}`;

  return (
    <div className="flex min-h-screen bg-muted/20">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 border-r bg-background lg:block">
        <SidebarNav items={navItems} />
      </aside>
      <div className="flex min-h-screen w-full flex-col lg:pl-64">
        <Navbar
          navItems={navItems}
          fullName={formatFullName(profile.first_name, profile.last_name)}
          role={profile.role}
          unreadCount={unreadCount}
          notificationsHref={`${basePath}/notifications`}
          profileHref={profile.role === "student" ? "/student/profile" : undefined}
        />
        <main className="flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
