import {
  LayoutDashboard,
  Users,
  UserCog,
  Layers,
  CalendarDays,
  ClipboardCheck,
  FileText,
  Bell,
  ScrollText,
  Settings,
  UserCircle,
  type LucideIcon,
} from "lucide-react";
import type { UserRole } from "@/types/database";

export interface NavItem {
  label: string;
  href: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: Record<UserRole, NavItem[]> = {
  admin: [
    { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
    { label: "Groups", href: "/admin/groups", icon: Layers },
    { label: "Students", href: "/admin/students", icon: Users },
    { label: "Leaders", href: "/admin/leaders", icon: UserCog },
    { label: "Schedule", href: "/admin/schedule", icon: CalendarDays },
    { label: "Attendance", href: "/admin/attendance", icon: ClipboardCheck },
    { label: "Assignments", href: "/admin/assignments", icon: FileText },
    { label: "Notifications", href: "/admin/notifications", icon: Bell },
    { label: "Audit Log", href: "/admin/audit-log", icon: ScrollText },
    { label: "Settings", href: "/admin/settings", icon: Settings },
  ],
  leader: [
    { label: "Dashboard", href: "/leader", icon: LayoutDashboard },
    { label: "My Group", href: "/leader/group", icon: Layers },
    { label: "Schedule", href: "/leader/schedule", icon: CalendarDays },
    { label: "Attendance", href: "/leader/attendance", icon: ClipboardCheck },
    { label: "Assignments", href: "/leader/assignments", icon: FileText },
    { label: "Notifications", href: "/leader/notifications", icon: Bell },
  ],
  student: [
    { label: "Dashboard", href: "/student", icon: LayoutDashboard },
    { label: "My Group", href: "/student/group", icon: Layers },
    { label: "Schedule", href: "/student/schedule", icon: CalendarDays },
    { label: "Attendance", href: "/student/attendance", icon: ClipboardCheck },
    { label: "Assignments", href: "/student/assignments", icon: FileText },
    { label: "Notifications", href: "/student/notifications", icon: Bell },
    { label: "My Profile", href: "/student/profile", icon: UserCircle },
  ],
};
