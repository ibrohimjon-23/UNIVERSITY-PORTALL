import { z } from "zod";

const usernameField = z
  .string()
  .trim()
  .min(3, "Username must be at least 3 characters")
  .max(32)
  .regex(/^[a-zA-Z0-9_.]+$/, "Only letters, numbers, dots and underscores are allowed");

const pinField = z
  .string()
  .min(4, "PIN must be at least 4 digits")
  .max(64)
  .regex(/^[0-9]+$/, "PIN must be numeric");

export const createStudentSchema = z.object({
  first_name: z.string().trim().min(1, "First name is required").max(64),
  last_name: z.string().trim().min(1, "Last name is required").max(64),
  username: usernameField,
  pin: pinField,
  student_id: z.string().trim().min(1, "Student ID is required").max(32),
  group_id: z.string().uuid("Select a group"),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, "Enter a valid phone number")
    .optional()
    .or(z.literal("")),
  email: z.string().trim().email("Enter a valid email").optional().or(z.literal("")),
});

export type CreateStudentInput = z.infer<typeof createStudentSchema>;

export const updateStudentSchema = z.object({
  id: z.string().uuid(),
  first_name: z.string().trim().min(1).max(64),
  last_name: z.string().trim().min(1).max(64),
  student_id: z.string().trim().min(1).max(32),
  group_id: z.string().uuid(),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, "Enter a valid phone number")
    .optional()
    .or(z.literal("")),
  email: z.string().trim().email("Enter a valid email").optional().or(z.literal("")),
  is_active: z.coerce.boolean().optional(),
});

export type UpdateStudentInput = z.infer<typeof updateStudentSchema>;

export const createLeaderSchema = z.object({
  first_name: z.string().trim().min(1, "First name is required").max(64),
  last_name: z.string().trim().min(1, "Last name is required").max(64),
  username: usernameField,
  pin: pinField,
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, "Enter a valid phone number")
    .optional()
    .or(z.literal("")),
  group_id: z.string().uuid("Select a group"),
});

export type CreateLeaderInput = z.infer<typeof createLeaderSchema>;

export const updateLeaderSchema = z.object({
  id: z.string().uuid(),
  first_name: z.string().trim().min(1).max(64),
  last_name: z.string().trim().min(1).max(64),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\-\s()]{7,20}$/, "Enter a valid phone number")
    .optional()
    .or(z.literal("")),
  is_active: z.coerce.boolean().optional(),
});

export type UpdateLeaderInput = z.infer<typeof updateLeaderSchema>;
