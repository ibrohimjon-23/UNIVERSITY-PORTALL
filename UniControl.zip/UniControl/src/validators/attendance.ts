import { z } from "zod";

export const createAttendanceSessionSchema = z.object({
  group_id: z.string().uuid("Select a group"),
  subject_id: z.string().uuid("Select a subject"),
  teacher_id: z.string().uuid().optional().or(z.literal("")).nullable(),
  schedule_id: z.string().uuid().optional().or(z.literal("")).nullable(),
  duration_minutes: z.coerce.number().int().min(5).max(240).default(90),
});

export type CreateAttendanceSessionInput = z.infer<typeof createAttendanceSessionSchema>;

export const submitAttendanceSchema = z.object({
  session_id: z.string().uuid(),
  qr_token: z.string().min(10).max(256),
  latitude: z.coerce.number().min(-90).max(90),
  longitude: z.coerce.number().min(-180).max(180),
  accuracy: z.coerce.number().min(0).max(100000).optional().nullable(),
});

export type SubmitAttendanceInput = z.infer<typeof submitAttendanceSchema>;

export const manualAttendanceOverrideSchema = z.object({
  attendance_record_id: z.string().uuid().optional(),
  student_id: z.string().uuid(),
  attendance_session_id: z.string().uuid(),
  status: z.enum(["present", "absent", "late", "excused"]),
});

export type ManualAttendanceOverrideInput = z.infer<typeof manualAttendanceOverrideSchema>;
