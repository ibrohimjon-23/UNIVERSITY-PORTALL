import { z } from "zod";

export const groupSchema = z.object({
  group_name: z.string().trim().min(2, "Group name is required").max(64),
  faculty: z.string().trim().min(2, "Faculty is required").max(128),
  course: z.coerce.number().int().min(1).max(8),
  year: z.coerce.number().int().min(2000).max(2100),
  description: z.string().trim().max(1000).optional().or(z.literal("")),
  leader_id: z.string().uuid().optional().or(z.literal("")).nullable(),
});

export type GroupInput = z.infer<typeof groupSchema>;
