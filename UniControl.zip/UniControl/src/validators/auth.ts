import { z } from "zod";

export const loginSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3, "Username must be at least 3 characters")
    .max(32, "Username is too long")
    .regex(/^[a-zA-Z0-9_.]+$/, "Only letters, numbers, dots and underscores are allowed"),
  pin: z
    .string()
    .min(4, "PIN must be at least 4 digits")
    .max(64, "PIN is too long")
    .regex(/^[0-9]+$/, "PIN must be numeric"),
});

export type LoginInput = z.infer<typeof loginSchema>;
