import { z } from "zod";

export const assignmentSchema = z.object({
  title: z.string().trim().min(2, "Title is required").max(200),
  description: z.string().trim().max(5000).optional().or(z.literal("")),
  group_id: z.string().uuid("Select a group"),
  subject_id: z.string().uuid("Select a subject"),
  deadline: z.string().refine((v) => !Number.isNaN(Date.parse(v)), "Enter a valid date/time"),
});

export type AssignmentInput = z.infer<typeof assignmentSchema>;

export const submissionSchema = z.object({
  assignment_id: z.string().uuid(),
  text_answer: z.string().trim().max(10000).optional().or(z.literal("")),
});

export type SubmissionInput = z.infer<typeof submissionSchema>;

export const reviewSubmissionSchema = z.object({
  submission_id: z.string().uuid(),
  grade: z.coerce.number().min(0).max(100).optional(),
  feedback: z.string().trim().max(5000).optional().or(z.literal("")),
});

export type ReviewSubmissionInput = z.infer<typeof reviewSubmissionSchema>;

export const MAX_SUBMISSION_FILE_BYTES = 10 * 1024 * 1024;
export const ALLOWED_SUBMISSION_MIME_TYPES = [
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/zip",
  "image/png",
  "image/jpeg",
  "text/plain",
];
