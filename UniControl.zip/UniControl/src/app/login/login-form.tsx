"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { GraduationCap, Loader2 } from "lucide-react";
import { loginAction, type LoginResult } from "@/features/auth/actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";

const initialState: LoginResult = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" className="w-full" size="lg" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      Sign in
    </Button>
  );
}

export function LoginForm({ deactivated }: { deactivated?: boolean }) {
  const [state, formAction] = useActionState(loginAction, initialState);

  return (
    <div className="w-full max-w-sm space-y-6">
      <div className="flex flex-col items-center gap-2 text-center">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <GraduationCap className="h-6 w-6" />
        </div>
        <h1 className="text-2xl font-semibold tracking-tight">UniControl</h1>
        <p className="text-sm text-muted-foreground">Sign in with your username and PIN</p>
      </div>

      {deactivated ? (
        <Alert variant="destructive">
          <AlertDescription>Your account has been deactivated. Contact an administrator.</AlertDescription>
        </Alert>
      ) : null}

      {state.error ? (
        <Alert variant="destructive">
          <AlertDescription>{state.error}</AlertDescription>
        </Alert>
      ) : null}

      <form action={formAction} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="username">Username</Label>
          <Input id="username" name="username" autoComplete="username" required placeholder="john.smith" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="pin">PIN</Label>
          <Input
            id="pin"
            name="pin"
            type="password"
            inputMode="numeric"
            autoComplete="current-password"
            required
            placeholder="••••••"
          />
        </div>
        <SubmitButton />
      </form>
    </div>
  );
}
