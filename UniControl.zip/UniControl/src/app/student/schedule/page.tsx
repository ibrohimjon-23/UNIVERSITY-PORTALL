import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { WeeklyTimetable } from "@/features/schedules/weekly-timetable";
import { listSchedulesForGroup } from "@/features/schedules/queries";
import { EmptyState } from "@/components/shared/empty-state";
import { Layers } from "lucide-react";

export const metadata: Metadata = { title: "Schedule" };

export default async function StudentSchedulePage() {
  const student = await requireRole("student");

  if (!student.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const schedules = await listSchedulesForGroup(student.group_id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Schedule</h1>
        <p className="text-sm text-muted-foreground">Your weekly class timetable.</p>
      </div>
      <WeeklyTimetable schedules={schedules} />
    </div>
  );
}
