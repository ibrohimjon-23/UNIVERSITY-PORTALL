import type { Metadata } from "next";
import { FileText, Layers } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/shared/empty-state";
import { SubmissionForm } from "@/features/assignments/submission-form";
import { listAssignmentsForStudent } from "@/features/assignments/queries";

export const metadata: Metadata = { title: "Assignments" };

const STATUS_VARIANT = {
  pending: "outline",
  submitted: "secondary",
  late: "warning",
  reviewed: "success",
} as const;

export default async function StudentAssignmentsPage() {
  const student = await requireRole("student");

  if (!student.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const assignments = await listAssignmentsForStudent(student.id, student.group_id);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Assignments</h1>
        <p className="text-sm text-muted-foreground">View and submit your assignments.</p>
      </div>

      {assignments.length === 0 ? (
        <EmptyState icon={FileText} title="No assignments yet" />
      ) : (
        <div className="space-y-4">
          {assignments.map((a) => {
            const overdue = !a.mySubmission && new Date(a.deadline) < new Date();
            const status = a.mySubmission?.status ?? (overdue ? "late" : "pending");
            return (
              <Card key={a.id}>
                <CardHeader className="flex flex-row items-start justify-between space-y-0">
                  <div>
                    <CardTitle className="text-base">{a.title}</CardTitle>
                    <CardDescription>
                      {a.subject?.name} · Due {new Date(a.deadline).toLocaleString()}
                    </CardDescription>
                  </div>
                  <Badge variant={STATUS_VARIANT[status as keyof typeof STATUS_VARIANT]} className="capitalize">
                    {status}
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-4">
                  {a.description ? <p className="text-sm text-muted-foreground">{a.description}</p> : null}
                  {a.mySubmission?.status === "reviewed" ? (
                    <div className="rounded-md border bg-muted/30 p-3 text-sm">
                      <p className="font-medium">Grade: {a.mySubmission.grade ?? "—"}</p>
                      {a.mySubmission.feedback ? <p className="mt-1 text-muted-foreground">{a.mySubmission.feedback}</p> : null}
                    </div>
                  ) : null}
                  <SubmissionForm
                    assignmentId={a.id}
                    studentId={student.id}
                    existing={a.mySubmission}
                    locked={a.mySubmission?.status === "reviewed"}
                  />
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
