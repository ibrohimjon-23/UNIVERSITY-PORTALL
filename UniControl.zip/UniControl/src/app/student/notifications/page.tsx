import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { NotificationList } from "@/features/notifications/notification-list";
import { listNotificationsForUser } from "@/features/notifications/list-queries";
import { QueryPagination } from "@/components/shared/query-pagination";

export const metadata: Metadata = { title: "Notifications" };

interface PageProps {
  searchParams: Promise<{ page?: string }>;
}

export default async function StudentNotificationsPage({ searchParams }: PageProps) {
  const student = await requireRole("student");
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const { rows, total, pageSize } = await listNotificationsForUser(student, page);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Notifications</h1>
        <p className="text-sm text-muted-foreground">Announcements from your leader and the university.</p>
      </div>
      <NotificationList notifications={rows} />
      <QueryPagination page={page} pageSize={pageSize} total={total} />
    </div>
  );
}
