import type { Metadata } from "next";
import { Users, CheckCircle2, Clock, XCircle, FileText, Bell, Layers } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { StatCard } from "@/components/shared/stat-card";
import { EmptyState } from "@/components/shared/empty-state";
import { getLeaderDashboardStats } from "@/features/dashboard/queries";
import { getGroupById } from "@/features/groups/queries";

export const metadata: Metadata = { title: "Dashboard" };

export default async function LeaderDashboardPage() {
  const leader = await requireRole("leader");

  if (!leader.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const [stats, group] = await Promise.all([getLeaderDashboardStats(), getGroupById(leader.group_id)]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{group?.group_name ?? "Dashboard"}</h1>
        <p className="text-sm text-muted-foreground">{group?.faculty} · Course {group?.course}</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Students" value={stats.total_students} icon={Users} />
        <StatCard label="Active assignments" value={stats.active_assignments} icon={FileText} />
        <StatCard label="Unread notifications" value={stats.unread_notifications} icon={Bell} />
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">Today&apos;s attendance</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Present" value={stats.today_present} icon={CheckCircle2} tone="success" />
          <StatCard label="Late" value={stats.today_late} icon={Clock} tone="warning" />
          <StatCard label="Absent" value={stats.today_absent} icon={XCircle} tone="destructive" />
          <StatCard label="Excused" value={stats.today_excused} icon={CheckCircle2} />
        </div>
      </div>
    </div>
  );
}
