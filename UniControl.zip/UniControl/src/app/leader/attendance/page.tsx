import type { Metadata } from "next";
import Link from "next/link";
import { ClipboardCheck, Layers } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QueryPagination } from "@/components/shared/query-pagination";
import { SessionFormDialog } from "@/features/attendance/session-form-dialog";
import { listAttendanceSessions } from "@/features/attendance/queries";
import { listAllGroups } from "@/features/groups/queries";
import { listSubjects, listTeachers } from "@/features/catalog/queries";

export const metadata: Metadata = { title: "Attendance" };

interface PageProps {
  searchParams: Promise<{ page?: string }>;
}

export default async function LeaderAttendancePage({ searchParams }: PageProps) {
  const leader = await requireRole("leader");
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  if (!leader.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const [{ rows, total, pageSize }, groups, subjects, teachers] = await Promise.all([
    listAttendanceSessions({ groupId: leader.group_id, page }),
    listAllGroups(),
    listSubjects(),
    listTeachers(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Attendance</h1>
          <p className="text-sm text-muted-foreground">Start and review attendance for your group.</p>
        </div>
        <SessionFormDialog groups={groups} subjects={subjects} teachers={teachers} lockedGroupId={leader.group_id} />
      </div>

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={ClipboardCheck} title="No attendance sessions yet" />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Checked in</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>{s.session_date}</TableCell>
                    <TableCell>{s.subject?.name ?? "—"}</TableCell>
                    <TableCell>
                      <Badge variant={s.status === "active" ? "success" : "secondary"} className="capitalize">
                        {s.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {s.present_count}/{s.total_count}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/leader/attendance/${s.id}`}>View</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
