import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { NotificationFormDialog } from "@/features/notifications/notification-form-dialog";
import { NotificationList } from "@/features/notifications/notification-list";
import { listNotificationsForUser } from "@/features/notifications/list-queries";
import { listGroupStudentsLite } from "@/features/students/queries";
import { QueryPagination } from "@/components/shared/query-pagination";

export const metadata: Metadata = { title: "Notifications" };

interface PageProps {
  searchParams: Promise<{ page?: string }>;
}

export default async function LeaderNotificationsPage({ searchParams }: PageProps) {
  const leader = await requireRole("leader");
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, students] = await Promise.all([
    listNotificationsForUser(leader, page),
    leader.group_id ? listGroupStudentsLite(leader.group_id) : Promise.resolve([]),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Notifications</h1>
          <p className="text-sm text-muted-foreground">Message your group or a specific student.</p>
        </div>
        {leader.group_id ? (
          <NotificationFormDialog role="leader" groups={[]} students={students} lockedGroupId={leader.group_id} />
        ) : null}
      </div>
      <NotificationList notifications={rows} />
      <QueryPagination page={page} pageSize={pageSize} total={total} />
    </div>
  );
}
