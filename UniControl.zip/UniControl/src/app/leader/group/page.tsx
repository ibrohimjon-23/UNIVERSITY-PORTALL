import type { Metadata } from "next";
import { Layers, Users } from "lucide-react";
import { requireRole } from "@/lib/auth";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QuerySearch } from "@/components/shared/query-search";
import { QueryPagination } from "@/components/shared/query-pagination";
import { StudentFormDialog } from "@/features/students/student-form-dialog";
import { StudentRowActions } from "@/features/students/student-row-actions";
import { listStudents } from "@/features/students/queries";
import { getGroupById } from "@/features/groups/queries";

export const metadata: Metadata = { title: "My Group" };

interface PageProps {
  searchParams: Promise<{ q?: string; page?: string }>;
}

export default async function LeaderGroupPage({ searchParams }: PageProps) {
  const leader = await requireRole("leader");
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  if (!leader.group_id) {
    return <EmptyState icon={Layers} title="No group assigned" description="Contact an administrator to be assigned to a group." />;
  }

  const [group, { rows, total, pageSize }] = await Promise.all([
    getGroupById(leader.group_id),
    listStudents({ query: params.q, scopeGroupId: leader.group_id, page }),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{group?.group_name}</h1>
          <p className="text-sm text-muted-foreground">
            {group?.faculty} · Course {group?.course} · {group?.year}
          </p>
        </div>
        {group ? <StudentFormDialog groups={[group]} lockedGroupId={group.id} /> : null}
      </div>

      <QuerySearch placeholder="Search students..." />

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={Users} title="No students yet" description="Add your first student to this group." />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Student ID</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      {student.first_name} {student.last_name}
                      <div className="text-xs text-muted-foreground">@{student.username}</div>
                    </TableCell>
                    <TableCell>{student.student_id}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{student.phone ?? student.email ?? "—"}</TableCell>
                    <TableCell>
                      <Badge variant={student.is_active ? "success" : "secondary"}>{student.is_active ? "Active" : "Inactive"}</Badge>
                    </TableCell>
                    <TableCell>
                      <StudentRowActions student={student} groups={group ? [group] : []} lockedGroupId={leader.group_id!} isAdmin={false} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
