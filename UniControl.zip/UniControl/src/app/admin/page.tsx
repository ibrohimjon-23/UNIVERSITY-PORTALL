import type { Metadata } from "next";
import Link from "next/link";
import {
  Users,
  Layers,
  UserCog,
  CheckCircle2,
  Clock,
  XCircle,
  FileText,
  Bell,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { StatCard } from "@/components/shared/stat-card";
import { getAdminDashboardStats, getAttendanceTrend } from "@/features/dashboard/queries";
import { AttendanceTrendChart } from "@/features/dashboard/attendance-trend-chart";

export const metadata: Metadata = { title: "Dashboard" };

export default async function AdminDashboardPage() {
  const [stats, trend] = await Promise.all([getAdminDashboardStats(), getAttendanceTrend(14)]);
  const totalToday = stats.today_present + stats.today_late + stats.today_absent + stats.today_excused;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Live overview of the university, computed from real data.</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Total students" value={stats.total_students} icon={Users} />
        <StatCard label="Total groups" value={stats.total_groups} icon={Layers} />
        <StatCard label="Total leaders" value={stats.total_leaders} icon={UserCog} />
      </div>

      <div>
        <h2 className="mb-3 text-sm font-medium text-muted-foreground">Today&apos;s attendance</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            label="Present"
            value={stats.today_present}
            icon={CheckCircle2}
            tone="success"
            hint={totalToday > 0 ? `${Math.round((stats.today_present / totalToday) * 100)}% of today` : undefined}
          />
          <StatCard label="Late" value={stats.today_late} icon={Clock} tone="warning" />
          <StatCard label="Absent" value={stats.today_absent} icon={XCircle} tone="destructive" />
          <StatCard label="Excused" value={stats.today_excused} icon={CheckCircle2} />
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Attendance trend</CardTitle>
            <CardDescription>Present vs. late check-ins over the last 14 days.</CardDescription>
          </CardHeader>
          <CardContent>
            <AttendanceTrendChart data={trend} />
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Link href="/admin/assignments">
            <StatCard label="Active assignments" value={stats.active_assignments} icon={FileText} />
          </Link>
          <Link href="/admin/notifications">
            <StatCard label="Unread notifications" value={stats.unread_notifications} icon={Bell} />
          </Link>
        </div>
      </div>
    </div>
  );
}
