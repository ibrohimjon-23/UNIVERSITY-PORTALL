import type { Metadata } from "next";
import { FileText } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { QueryPagination } from "@/components/shared/query-pagination";
import { AssignmentFormDialog } from "@/features/assignments/assignment-form-dialog";
import { AssignmentRowActions } from "@/features/assignments/assignment-row-actions";
import { listAssignments, listSubmissionsForAssignment } from "@/features/assignments/queries";
import { listAllGroups } from "@/features/groups/queries";
import { listSubjects } from "@/features/catalog/queries";

export const metadata: Metadata = { title: "Assignments" };

interface PageProps {
  searchParams: Promise<{ group?: string; page?: string }>;
}

export default async function AdminAssignmentsPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, groups, subjects] = await Promise.all([
    listAssignments({ groupId: params.group, page }),
    listAllGroups(),
    listSubjects(),
  ]);

  const submissionsByAssignment = await Promise.all(rows.map((a) => listSubmissionsForAssignment(a.id)));

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Assignments</h1>
          <p className="text-sm text-muted-foreground">Create and review assignments across all groups.</p>
        </div>
        <AssignmentFormDialog groups={groups} subjects={subjects} />
      </div>

      <QueryFilterSelect paramKey="group" placeholder="All groups" options={groups.map((g) => ({ value: g.id, label: g.group_name }))} />

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={FileText} title="No assignments yet" />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Title</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Deadline</TableHead>
                  <TableHead>Submissions</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((a, i) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.title}</TableCell>
                    <TableCell>{a.group?.group_name ?? "—"}</TableCell>
                    <TableCell>{a.subject?.name ?? "—"}</TableCell>
                    <TableCell>{new Date(a.deadline).toLocaleString()}</TableCell>
                    <TableCell>
                      {a.submission_count}/{a.group_size}
                    </TableCell>
                    <TableCell>
                      <AssignmentRowActions assignment={a} submissions={submissionsByAssignment[i] ?? []} groups={groups} subjects={subjects} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
