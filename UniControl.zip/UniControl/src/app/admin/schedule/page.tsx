import type { Metadata } from "next";
import { BookOpen, Contact } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { EmptyState } from "@/components/shared/empty-state";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { ScheduleFormDialog } from "@/features/schedules/schedule-form-dialog";
import { ScheduleRowActions } from "@/features/schedules/schedule-row-actions";
import { WeeklyTimetable } from "@/features/schedules/weekly-timetable";
import { SubjectFormDialog, TeacherFormDialog, DeleteSubjectButton, DeleteTeacherButton } from "@/features/catalog/catalog-dialogs";
import { listSchedulesForGroup } from "@/features/schedules/queries";
import { listAllGroups } from "@/features/groups/queries";
import { listSubjects, listTeachers } from "@/features/catalog/queries";

export const metadata: Metadata = { title: "Schedule" };

interface PageProps {
  searchParams: Promise<{ group?: string }>;
}

export default async function AdminSchedulePage({ searchParams }: PageProps) {
  const params = await searchParams;
  const groups = await listAllGroups();
  const activeGroupId = params.group || groups[0]?.id;

  const [schedules, subjects, teachers] = await Promise.all([
    activeGroupId ? listSchedulesForGroup(activeGroupId) : Promise.resolve([]),
    listSubjects(),
    listTeachers(),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Schedule</h1>
        <p className="text-sm text-muted-foreground">Manage weekly timetables, subjects and teachers.</p>
      </div>

      <Tabs defaultValue="timetable">
        <TabsList>
          <TabsTrigger value="timetable">Timetable</TabsTrigger>
          <TabsTrigger value="catalog">Subjects &amp; Teachers</TabsTrigger>
        </TabsList>

        <TabsContent value="timetable" className="space-y-4">
          <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <QueryFilterSelect
              paramKey="group"
              placeholder="Select a group"
              options={groups.map((g) => ({ value: g.id, label: g.group_name }))}
            />
            {activeGroupId ? (
              <ScheduleFormDialog groups={groups} subjects={subjects} teachers={teachers} lockedGroupId={activeGroupId} />
            ) : null}
          </div>

          {!activeGroupId ? (
            <EmptyState icon={BookOpen} title="No groups yet" description="Create a group before scheduling classes." />
          ) : (
            <WeeklyTimetable
              schedules={schedules}
              actions={(s) => (
                <ScheduleRowActions schedule={s} groups={groups} subjects={subjects} teachers={teachers} lockedGroupId={activeGroupId} />
              )}
            />
          )}
        </TabsContent>

        <TabsContent value="catalog" className="space-y-6">
          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="flex items-center justify-between">
                <h2 className="font-medium">Subjects</h2>
                <SubjectFormDialog />
              </div>
              {subjects.length === 0 ? (
                <EmptyState icon={BookOpen} title="No subjects yet" />
              ) : (
                <div className="divide-y">
                  {subjects.map((s) => (
                    <div key={s.id} className="flex items-center justify-between py-2">
                      <div>
                        <p className="text-sm font-medium">{s.name}</p>
                        <p className="text-xs text-muted-foreground">{s.code}</p>
                      </div>
                      <DeleteSubjectButton id={s.id} name={s.name} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="space-y-4 p-6">
              <div className="flex items-center justify-between">
                <h2 className="font-medium">Teachers</h2>
                <TeacherFormDialog />
              </div>
              {teachers.length === 0 ? (
                <EmptyState icon={Contact} title="No teachers yet" />
              ) : (
                <div className="divide-y">
                  {teachers.map((t) => (
                    <div key={t.id} className="flex items-center justify-between py-2">
                      <div>
                        <p className="text-sm font-medium">
                          {t.first_name} {t.last_name}
                        </p>
                        <p className="text-xs text-muted-foreground">{t.email ?? t.phone ?? "—"}</p>
                      </div>
                      <DeleteTeacherButton id={t.id} name={`${t.first_name} ${t.last_name}`} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
