import type { Metadata } from "next";
import { Layers } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QuerySearch } from "@/components/shared/query-search";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { QueryPagination } from "@/components/shared/query-pagination";
import { GroupFormDialog } from "@/features/groups/group-form-dialog";
import { GroupRowActions } from "@/features/groups/group-row-actions";
import { listGroups, getDistinctFaculties } from "@/features/groups/queries";
import { listAvailableLeaders } from "@/features/leaders/queries";

export const metadata: Metadata = { title: "Groups" };

interface PageProps {
  searchParams: Promise<{ q?: string; faculty?: string; course?: string; page?: string }>;
}

export default async function AdminGroupsPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, faculties, availableLeaders] = await Promise.all([
    listGroups({
      query: params.q,
      faculty: params.faculty,
      course: params.course ? Number(params.course) : undefined,
      page,
    }),
    getDistinctFaculties(),
    listAvailableLeaders(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Groups</h1>
          <p className="text-sm text-muted-foreground">Manage university groups, their leaders and members.</p>
        </div>
        <GroupFormDialog />
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <QuerySearch placeholder="Search by group name or faculty..." />
        <QueryFilterSelect
          paramKey="faculty"
          placeholder="All faculties"
          options={faculties.map((f) => ({ value: f, label: f }))}
        />
        <QueryFilterSelect
          paramKey="course"
          placeholder="All courses"
          options={[1, 2, 3, 4, 5, 6].map((c) => ({ value: String(c), label: `Course ${c}` }))}
        />
      </div>

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={Layers} title="No groups found" description="Create your first group to get started." />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Group</TableHead>
                  <TableHead>Faculty</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>Leader</TableHead>
                  <TableHead>Students</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((group) => (
                  <TableRow key={group.id}>
                    <TableCell className="font-medium">{group.group_name}</TableCell>
                    <TableCell>{group.faculty}</TableCell>
                    <TableCell>
                      Course {group.course} · {group.year}
                    </TableCell>
                    <TableCell>
                      {group.leader ? (
                        `${group.leader.first_name} ${group.leader.last_name}`
                      ) : (
                        <Badge variant="outline">Unassigned</Badge>
                      )}
                    </TableCell>
                    <TableCell>{group.student_count}</TableCell>
                    <TableCell>
                      <GroupRowActions group={group} availableLeaders={availableLeaders} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
