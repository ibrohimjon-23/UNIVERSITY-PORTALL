import type { Metadata } from "next";
import { ScrollText } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QuerySearch } from "@/components/shared/query-search";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { QueryPagination } from "@/components/shared/query-pagination";
import { listAuditLogs, getDistinctEntityTypes } from "@/features/audit/queries";

export const metadata: Metadata = { title: "Audit Log" };

interface PageProps {
  searchParams: Promise<{ q?: string; entity?: string; page?: string }>;
}

export default async function AuditLogPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, entityTypes] = await Promise.all([
    listAuditLogs({ query: params.q, entityType: params.entity, page }),
    getDistinctEntityTypes(),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Audit Log</h1>
        <p className="text-sm text-muted-foreground">A record of sensitive actions taken across the system.</p>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <QuerySearch placeholder="Search by action..." />
        <QueryFilterSelect
          paramKey="entity"
          placeholder="All entity types"
          options={entityTypes.map((t) => ({ value: t, label: t }))}
        />
      </div>

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={ScrollText} title="No audit entries yet" />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>When</TableHead>
                  <TableHead>Actor</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Entity</TableHead>
                  <TableHead>IP</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="whitespace-nowrap text-sm">{new Date(log.created_at).toLocaleString()}</TableCell>
                    <TableCell>
                      {log.actor ? (
                        <div>
                          <p className="text-sm">
                            {log.actor.first_name} {log.actor.last_name}
                          </p>
                          <Badge variant="outline" className="capitalize">
                            {log.actor.role}
                          </Badge>
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">System</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">{log.action}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {log.entity_type}
                      {log.entity_id ? <span className="ml-1 font-mono text-xs">{log.entity_id.slice(0, 8)}</span> : null}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{log.ip_address ?? "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
