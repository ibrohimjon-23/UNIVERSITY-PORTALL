"use client";

import { useActionState, useEffect } from "react";
import { useFormStatus } from "react-dom";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { updateSettingsAction, type ActionResult } from "@/features/settings/actions";
import type { UniversitySettings } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      Save settings
    </Button>
  );
}

export function SettingsForm({ settings }: { settings: UniversitySettings }) {
  const [state, formAction] = useActionState(updateSettingsAction, initial);

  useEffect(() => {
    if (state.success) toast.success("Settings saved");
    else if (state.error) toast.error(state.error);
  }, [state]);

  return (
    <form action={formAction} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>University</CardTitle>
          <CardDescription>Basic identity and timezone.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="university_name">University name</Label>
            <Input id="university_name" name="university_name" defaultValue={settings.university_name} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="timezone">Timezone</Label>
            <Input id="timezone" name="timezone" defaultValue={settings.timezone} required placeholder="Asia/Tashkent" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Attendance geofence</CardTitle>
          <CardDescription>
            The campus coordinates and radius students must be within to check in. Changing these affects every future
            attendance check — do not change lightly.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-3">
          <div className="space-y-2">
            <Label htmlFor="latitude">Latitude</Label>
            <Input id="latitude" name="latitude" type="number" step="0.000001" defaultValue={settings.latitude} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="longitude">Longitude</Label>
            <Input id="longitude" name="longitude" type="number" step="0.000001" defaultValue={settings.longitude} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="attendance_radius_m">Radius (meters)</Label>
            <Input id="attendance_radius_m" name="attendance_radius_m" type="number" min={10} max={5000} defaultValue={settings.attendance_radius_m} required />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Attendance rules</CardTitle>
          <CardDescription>QR code lifetime and the late-arrival grace period.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="qr_expiry_seconds">QR expiration (seconds)</Label>
            <Input id="qr_expiry_seconds" name="qr_expiry_seconds" type="number" min={15} max={300} defaultValue={settings.qr_expiry_seconds} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="late_after_minutes">Mark late after (minutes)</Label>
            <Input id="late_after_minutes" name="late_after_minutes" type="number" min={0} max={120} defaultValue={settings.late_after_minutes} required />
          </div>
        </CardContent>
      </Card>

      <SubmitButton />
    </form>
  );
}
