import type { Metadata } from "next";
import Link from "next/link";
import { ClipboardCheck } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { QueryPagination } from "@/components/shared/query-pagination";
import { SessionFormDialog } from "@/features/attendance/session-form-dialog";
import { listAttendanceSessions } from "@/features/attendance/queries";
import { listAllGroups } from "@/features/groups/queries";
import { listSubjects, listTeachers } from "@/features/catalog/queries";

export const metadata: Metadata = { title: "Attendance" };

interface PageProps {
  searchParams: Promise<{ group?: string; page?: string }>;
}

export default async function AdminAttendancePage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, groups, subjects, teachers] = await Promise.all([
    listAttendanceSessions({ groupId: params.group, page }),
    listAllGroups(),
    listSubjects(),
    listTeachers(),
  ]);
  const groupById = new Map(groups.map((g) => [g.id, g]));

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Attendance</h1>
          <p className="text-sm text-muted-foreground">Start and review attendance sessions across all groups.</p>
        </div>
        <SessionFormDialog groups={groups} subjects={subjects} teachers={teachers} />
      </div>

      <QueryFilterSelect paramKey="group" placeholder="All groups" options={groups.map((g) => ({ value: g.id, label: g.group_name }))} />

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={ClipboardCheck} title="No attendance sessions yet" />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Checked in</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>{s.session_date}</TableCell>
                    <TableCell>{groupById.get(s.group_id)?.group_name ?? "—"}</TableCell>
                    <TableCell>{s.subject?.name ?? "—"}</TableCell>
                    <TableCell>
                      <Badge variant={s.status === "active" ? "success" : "secondary"} className="capitalize">
                        {s.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {s.present_count}/{s.total_count}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm" asChild>
                        <Link href={`/admin/attendance/${s.id}`}>View</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
