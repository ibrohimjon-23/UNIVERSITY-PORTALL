import type { Metadata } from "next";
import { requireRole } from "@/lib/auth";
import { NotificationFormDialog } from "@/features/notifications/notification-form-dialog";
import { NotificationList } from "@/features/notifications/notification-list";
import { listNotificationsForUser } from "@/features/notifications/list-queries";
import { listAllGroups } from "@/features/groups/queries";
import { listAllStudentsLite } from "@/features/students/queries";
import { QueryPagination } from "@/components/shared/query-pagination";

export const metadata: Metadata = { title: "Notifications" };

interface PageProps {
  searchParams: Promise<{ page?: string }>;
}

export default async function AdminNotificationsPage({ searchParams }: PageProps) {
  const admin = await requireRole("admin");
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, groups, students] = await Promise.all([
    listNotificationsForUser(admin, page),
    listAllGroups(),
    listAllStudentsLite(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Notifications</h1>
          <p className="text-sm text-muted-foreground">Send announcements to the whole university, leaders, groups or students.</p>
        </div>
        <NotificationFormDialog role="admin" groups={groups} students={students} />
      </div>
      <NotificationList notifications={rows} canDelete />
      <QueryPagination page={page} pageSize={pageSize} total={total} />
    </div>
  );
}
