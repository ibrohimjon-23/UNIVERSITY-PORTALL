import type { Metadata } from "next";
import { Users } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { QuerySearch } from "@/components/shared/query-search";
import { QueryFilterSelect } from "@/components/shared/query-filter-select";
import { QueryPagination } from "@/components/shared/query-pagination";
import { StudentFormDialog } from "@/features/students/student-form-dialog";
import { StudentRowActions } from "@/features/students/student-row-actions";
import { listStudents } from "@/features/students/queries";
import { listAllGroups } from "@/features/groups/queries";

export const metadata: Metadata = { title: "Students" };

interface PageProps {
  searchParams: Promise<{ q?: string; group?: string; status?: string; page?: string }>;
}

export default async function AdminStudentsPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const page = Number(params.page ?? 1);

  const [{ rows, total, pageSize }, groups] = await Promise.all([
    listStudents({
      query: params.q,
      groupId: params.group,
      status: params.status as "active" | "inactive" | undefined,
      page,
    }),
    listAllGroups(),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Students</h1>
          <p className="text-sm text-muted-foreground">All students across every group.</p>
        </div>
        <StudentFormDialog groups={groups} />
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <QuerySearch placeholder="Search by name, username or student ID..." />
        <QueryFilterSelect
          paramKey="group"
          placeholder="All groups"
          options={groups.map((g) => ({ value: g.id, label: g.group_name }))}
        />
        <QueryFilterSelect
          paramKey="status"
          placeholder="All statuses"
          options={[
            { value: "active", label: "Active" },
            { value: "inactive", label: "Inactive" },
          ]}
        />
      </div>

      <Card>
        {rows.length === 0 ? (
          <EmptyState icon={Users} title="No students found" description="Add a student to get started." />
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Student ID</TableHead>
                  <TableHead>Group</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-medium">
                      {student.first_name} {student.last_name}
                      <div className="text-xs text-muted-foreground">@{student.username}</div>
                    </TableCell>
                    <TableCell>{student.student_id}</TableCell>
                    <TableCell>{student.group?.group_name ?? <Badge variant="outline">None</Badge>}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {student.phone ?? student.email ?? "—"}
                    </TableCell>
                    <TableCell>
                      <Badge variant={student.is_active ? "success" : "secondary"}>
                        {student.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <StudentRowActions student={student} groups={groups} isAdmin />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <QueryPagination page={page} pageSize={pageSize} total={total} />
          </>
        )}
      </Card>
    </div>
  );
}
