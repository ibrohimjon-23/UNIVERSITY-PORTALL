export type UserRole = "admin" | "leader" | "student";
export type AttendanceStatus = "present" | "absent" | "late" | "excused";
export type AttendanceSessionStatus = "scheduled" | "active" | "closed" | "cancelled";
export type VerificationMethod = "location_qr" | "location_only" | "manual";
export type AssignmentStatus = "pending" | "submitted" | "late" | "reviewed";
export type NotificationTarget = "everyone" | "all_leaders" | "all_students" | "group" | "student";
export type NotificationType = "info" | "success" | "warning" | "urgent";

export interface Profile {
  id: string;
  role: UserRole;
  username: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  email: string | null;
  avatar_url: string | null;
  student_id: string | null;
  group_id: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Group {
  id: string;
  group_name: string;
  faculty: string;
  course: number;
  year: number;
  description: string | null;
  leader_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Subject {
  id: string;
  name: string;
  code: string;
  created_at: string;
}

export interface Teacher {
  id: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  email: string | null;
  created_at: string;
}

export interface Schedule {
  id: string;
  group_id: string;
  subject_id: string;
  teacher_id: string | null;
  room: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  created_at: string;
  updated_at: string;
}

export interface UniversitySettings {
  id: number;
  university_name: string;
  latitude: number;
  longitude: number;
  attendance_radius_m: number;
  timezone: string;
  qr_expiry_seconds: number;
  late_after_minutes: number;
  updated_at: string;
}

export interface AttendanceSession {
  id: string;
  group_id: string;
  subject_id: string;
  teacher_id: string | null;
  schedule_id: string | null;
  session_date: string;
  start_time: string;
  end_time: string;
  status: AttendanceSessionStatus;
  qr_token: string;
  qr_expires_at: string;
  created_by: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  student_id: string;
  group_id: string;
  subject_id: string;
  attendance_session_id: string;
  status: AttendanceStatus;
  latitude: number | null;
  longitude: number | null;
  location_accuracy: number | null;
  distance_from_university: number | null;
  verification_method: VerificationMethod;
  checked_at: string;
  created_at: string;
}

export interface Assignment {
  id: string;
  title: string;
  description: string | null;
  group_id: string;
  subject_id: string;
  deadline: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface AssignmentSubmission {
  id: string;
  assignment_id: string;
  student_id: string;
  text_answer: string | null;
  file_path: string | null;
  status: AssignmentStatus;
  grade: number | null;
  feedback: string | null;
  submitted_at: string | null;
  reviewed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  sender_id: string;
  target_type: NotificationTarget;
  target_id: string | null;
  created_at: string;
}

export interface NotificationRead {
  id: string;
  notification_id: string;
  user_id: string;
  read_at: string;
}

export interface AuditLog {
  id: string;
  actor_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  old_data: Record<string, unknown> | null;
  new_data: Record<string, unknown> | null;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

/**
 * We deliberately do NOT export a Supabase `Database` generic type here.
 * The installed @supabase/ssr and @supabase/supabase-js versions disagree
 * on the exact shape of their internal `GenericSchema` constraint, which
 * makes a fully generic `SupabaseClient<Database>` resolve every table's
 * row type to `never` instead of raising a clear error. Every Supabase
 * client in this project (`lib/supabase/{client,server,admin}.ts`) is
 * created untyped, and query results are cast to the row types above at
 * each call site instead. Postgres Row Level Security — not TypeScript —
 * is the actual security boundary; see `supabase/migrations/0001_init.sql`.
 */
