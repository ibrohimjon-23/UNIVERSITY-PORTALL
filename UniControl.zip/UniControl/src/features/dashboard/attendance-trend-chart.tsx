"use client";

import { Area, AreaChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { AttendanceTrendPoint } from "@/features/dashboard/queries";

export function AttendanceTrendChart({ data }: { data: AttendanceTrendPoint[] }) {
  const formatted = data.map((d) => ({
    ...d,
    label: new Date(d.day).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
  }));

  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={formatted} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="present" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(142 71% 35%)" stopOpacity={0.35} />
            <stop offset="95%" stopColor="hsl(142 71% 35%)" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="late" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(38 92% 40%)" stopOpacity={0.35} />
            <stop offset="95%" stopColor="hsl(38 92% 40%)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-muted" />
        <XAxis dataKey="label" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip
          contentStyle={{ borderRadius: 8, fontSize: 12, border: "1px solid hsl(214 32% 91%)" }}
          labelClassName="font-medium"
        />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" dataKey="present" name="Present" stroke="hsl(142 71% 35%)" fill="url(#present)" strokeWidth={2} />
        <Area type="monotone" dataKey="late" name="Late" stroke="hsl(38 92% 40%)" fill="url(#late)" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
