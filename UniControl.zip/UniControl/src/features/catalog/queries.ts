import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Subject, Teacher } from "@/types/database";

export async function listSubjects(): Promise<Subject[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("subjects").select("*").order("name");
  if (error) throw error;
  return data as Subject[];
}

export async function listTeachers(): Promise<Teacher[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("teachers").select("*").order("last_name");
  if (error) throw error;
  return data as Teacher[];
}
