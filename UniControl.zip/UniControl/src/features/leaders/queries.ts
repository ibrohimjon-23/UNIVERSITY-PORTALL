import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Group, Profile } from "@/types/database";

export interface LeaderWithGroup extends Profile {
  led_group: Pick<Group, "id" | "group_name"> | null;
}

export interface ListLeadersParams {
  query?: string;
  page?: number;
  pageSize?: number;
}

async function attachLedGroups(leaders: Profile[]): Promise<LeaderWithGroup[]> {
  if (leaders.length === 0) return [];
  const supabase = await createClient();
  const ids = leaders.map((l) => l.id);
  const { data: groups } = await supabase.from("groups").select("id, group_name, leader_id").in("leader_id", ids);
  const byLeader = new Map(
    (groups ?? []).map((g) => [g.leader_id as string, { id: g.id, group_name: g.group_name } as const]),
  );
  return leaders.map((l) => ({ ...l, led_group: byLeader.get(l.id) ?? null }));
}

export async function listLeaders(params: ListLeadersParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 10;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase.from("profiles").select("*", { count: "exact" }).eq("role", "leader");

  if (params.query) {
    query = query.or(
      `first_name.ilike.%${params.query}%,last_name.ilike.%${params.query}%,username.ilike.%${params.query}%`,
    );
  }

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const rows = await attachLedGroups((data ?? []) as Profile[]);
  return { rows, total: count ?? 0, page, pageSize };
}

export async function listAvailableLeaders(): Promise<Profile[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("role", "leader")
    .eq("is_active", true)
    .order("first_name");
  if (error) throw error;
  return data as Profile[];
}

export async function getLeaderById(id: string): Promise<LeaderWithGroup | null> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("profiles").select("*").eq("id", id).eq("role", "leader").maybeSingle();
  if (error || !data) return null;
  const [withGroup] = await attachLedGroups([data as Profile]);
  return withGroup ?? null;
}
