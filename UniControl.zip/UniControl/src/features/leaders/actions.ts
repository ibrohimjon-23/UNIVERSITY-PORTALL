"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireRole, usernameToAuthEmail } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { createLeaderSchema, updateLeaderSchema } from "@/validators/profile";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function createLeaderAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = createLeaderSchema.safeParse({
    first_name: formData.get("first_name"),
    last_name: formData.get("last_name"),
    username: formData.get("username"),
    pin: formData.get("pin"),
    phone: formData.get("phone"),
    group_id: formData.get("group_id"),
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  const adminClient = createAdminClient();
  const email = usernameToAuthEmail(parsed.data.username);

  const { data: created, error: createError } = await adminClient.auth.admin.createUser({
    email,
    password: parsed.data.pin,
    email_confirm: true,
    user_metadata: { role: "leader", username: parsed.data.username },
  });

  if (createError || !created.user) {
    return {
      error: createError?.message.includes("already been registered")
        ? "That username is already taken."
        : "Could not create the leader account.",
    };
  }

  const supabase = await createClient();
  const { error: profileError } = await supabase.from("profiles").insert({
    id: created.user.id,
    role: "leader",
    username: parsed.data.username,
    first_name: parsed.data.first_name,
    last_name: parsed.data.last_name,
    phone: parsed.data.phone || null,
    email: null,
    is_active: true,
  });

  if (profileError) {
    await adminClient.auth.admin.deleteUser(created.user.id);
    return { error: "Could not create the leader profile." };
  }

  const { error: assignError } = await supabase.rpc("fn_assign_leader", {
    p_group_id: parsed.data.group_id,
    p_leader_id: created.user.id,
  });

  if (assignError) {
    await adminClient.auth.admin.deleteUser(created.user.id);
    return { error: "Could not assign the leader to that group." };
  }

  await logAudit({
    actorId: admin.id,
    action: "leader.create",
    entityType: "profile",
    entityId: created.user.id,
    newData: { username: parsed.data.username, group_id: parsed.data.group_id },
  });

  revalidatePath("/admin/leaders");
  revalidatePath("/admin/groups");
  return { success: true };
}

export async function updateLeaderAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const parsed = updateLeaderSchema.safeParse({
    id: formData.get("id"),
    first_name: formData.get("first_name"),
    last_name: formData.get("last_name"),
    phone: formData.get("phone"),
    is_active: formData.get("is_active") === "true",
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  const supabase = await createClient();
  const { data: before } = await supabase.from("profiles").select("*").eq("id", parsed.data.id).maybeSingle();

  const { error } = await supabase
    .from("profiles")
    .update({
      first_name: parsed.data.first_name,
      last_name: parsed.data.last_name,
      phone: parsed.data.phone || null,
      is_active: parsed.data.is_active,
    })
    .eq("id", parsed.data.id);

  if (error) return { error: "Could not update leader." };

  await logAudit({
    actorId: admin.id,
    action: "leader.update",
    entityType: "profile",
    entityId: parsed.data.id,
    oldData: before,
  });
  revalidatePath("/admin/leaders");
  return { success: true };
}

export async function resetLeaderPinAction(leaderId: string, newPin: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  if (!/^[0-9]{4,64}$/.test(newPin)) return { error: "PIN must be numeric, at least 4 digits." };

  const adminClient = createAdminClient();
  const { error } = await adminClient.auth.admin.updateUserById(leaderId, { password: newPin });
  if (error) return { error: "Could not reset PIN." };

  await logAudit({ actorId: admin.id, action: "leader.reset_pin", entityType: "profile", entityId: leaderId });
  return { success: true };
}

export async function deleteLeaderAction(leaderId: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { data: before } = await supabase.from("profiles").select("*").eq("id", leaderId).maybeSingle();

  const adminClient = createAdminClient();
  const { error } = await adminClient.auth.admin.deleteUser(leaderId);
  if (error) return { error: "Could not delete leader." };

  await logAudit({ actorId: admin.id, action: "leader.delete", entityType: "profile", entityId: leaderId, oldData: before });
  revalidatePath("/admin/leaders");
  revalidatePath("/admin/groups");
  return { success: true };
}
