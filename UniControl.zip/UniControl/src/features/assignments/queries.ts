import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Assignment, AssignmentSubmission, Group, Profile, Subject } from "@/types/database";

export interface AssignmentWithRelations extends Assignment {
  subject: Subject | null;
  group: Pick<Group, "id" | "group_name"> | null;
  submission_count: number;
  group_size: number;
}

export interface ListAssignmentsParams {
  groupId?: string;
  page?: number;
  pageSize?: number;
}

export async function listAssignments(params: ListAssignmentsParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 10;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase.from("assignments").select("*", { count: "exact" });
  if (params.groupId) query = query.eq("group_id", params.groupId);

  const { data, count, error } = await query.order("deadline", { ascending: false }).range(from, to);
  if (error) throw error;

  const assignments = (data ?? []) as Assignment[];
  const subjectIds = Array.from(new Set(assignments.map((a) => a.subject_id)));
  const groupIds = Array.from(new Set(assignments.map((a) => a.group_id)));
  const assignmentIds = assignments.map((a) => a.id);

  const [{ data: subjects }, { data: groups }, { data: submissions }] = await Promise.all([
    subjectIds.length ? supabase.from("subjects").select("*").in("id", subjectIds) : Promise.resolve({ data: [] as Subject[] }),
    groupIds.length ? supabase.from("groups").select("id, group_name").in("id", groupIds) : Promise.resolve({ data: [] as Pick<Group, "id" | "group_name">[] }),
    assignmentIds.length
      ? supabase.from("assignment_submissions").select("assignment_id").in("assignment_id", assignmentIds)
      : Promise.resolve({ data: [] as { assignment_id: string }[] }),
  ]);

  const groupSizeByGroup = new Map<string, number>();
  if (groupIds.length) {
    const { data: members } = await supabase.from("profiles").select("group_id").in("group_id", groupIds).eq("role", "student");
    for (const m of members ?? []) {
      if (m.group_id) groupSizeByGroup.set(m.group_id, (groupSizeByGroup.get(m.group_id) ?? 0) + 1);
    }
  }

  const subjectById = new Map((subjects ?? []).map((s) => [s.id, s]));
  const groupById = new Map((groups ?? []).map((g) => [g.id, g]));
  const submissionCounts = new Map<string, number>();
  for (const s of submissions ?? []) {
    submissionCounts.set(s.assignment_id, (submissionCounts.get(s.assignment_id) ?? 0) + 1);
  }

  const rows: AssignmentWithRelations[] = assignments.map((a) => ({
    ...a,
    subject: subjectById.get(a.subject_id) ?? null,
    group: groupById.get(a.group_id) ?? null,
    submission_count: submissionCounts.get(a.id) ?? 0,
    group_size: groupSizeByGroup.get(a.group_id) ?? 0,
  }));

  return { rows, total: count ?? 0, page, pageSize };
}

export async function getAssignmentById(id: string): Promise<AssignmentWithRelations | null> {
  const { rows } = await listAssignments({ page: 1, pageSize: 1000 });
  return rows.find((a) => a.id === id) ?? null;
}

export interface SubmissionWithStudent extends AssignmentSubmission {
  student: Pick<Profile, "id" | "first_name" | "last_name" | "student_id"> | null;
}

export async function listSubmissionsForAssignment(assignmentId: string): Promise<SubmissionWithStudent[]> {
  const supabase = await createClient();
  const { data: submissions, error } = await supabase.from("assignment_submissions").select("*").eq("assignment_id", assignmentId);
  if (error) throw error;

  const studentIds = (submissions ?? []).map((s) => s.student_id);
  const { data: students } = studentIds.length
    ? await supabase.from("profiles").select("id, first_name, last_name, student_id").in("id", studentIds)
    : { data: [] };
  const studentById = new Map((students ?? []).map((s) => [s.id, s]));

  return (submissions ?? []).map((s) => ({ ...(s as AssignmentSubmission), student: studentById.get(s.student_id) ?? null }));
}

export async function getMySubmission(assignmentId: string, studentId: string): Promise<AssignmentSubmission | null> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("assignment_submissions")
    .select("*")
    .eq("assignment_id", assignmentId)
    .eq("student_id", studentId)
    .maybeSingle();
  return data as AssignmentSubmission | null;
}

export async function listAssignmentsForStudent(studentId: string, groupId: string | null) {
  if (!groupId) return [];
  const supabase = await createClient();
  const { data: assignments, error } = await supabase
    .from("assignments")
    .select("*")
    .eq("group_id", groupId)
    .order("deadline", { ascending: true });
  if (error) throw error;

  const assignmentIds = (assignments ?? []).map((a) => a.id);
  const subjectIds = Array.from(new Set((assignments ?? []).map((a) => a.subject_id)));

  const [{ data: subjects }, { data: mySubmissions }] = await Promise.all([
    subjectIds.length ? supabase.from("subjects").select("*").in("id", subjectIds) : Promise.resolve({ data: [] as Subject[] }),
    assignmentIds.length
      ? supabase.from("assignment_submissions").select("*").eq("student_id", studentId).in("assignment_id", assignmentIds)
      : Promise.resolve({ data: [] as AssignmentSubmission[] }),
  ]);

  const subjectById = new Map((subjects ?? []).map((s) => [s.id, s]));
  const submissionByAssignment = new Map((mySubmissions ?? []).map((s) => [s.assignment_id, s]));

  return (assignments ?? []).map((a) => ({
    ...(a as Assignment),
    subject: subjectById.get(a.subject_id) ?? null,
    mySubmission: submissionByAssignment.get(a.id) ?? null,
  }));
}
