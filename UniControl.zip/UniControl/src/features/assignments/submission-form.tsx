"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Paperclip, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { createClient } from "@/lib/supabase/client";
import { submitAssignmentAction } from "@/features/assignments/actions";
import { ALLOWED_SUBMISSION_MIME_TYPES, MAX_SUBMISSION_FILE_BYTES } from "@/validators/assignment";
import type { AssignmentSubmission } from "@/types/database";

interface SubmissionFormProps {
  assignmentId: string;
  studentId: string;
  existing: AssignmentSubmission | null;
  locked: boolean;
}

export function SubmissionForm({ assignmentId, studentId, existing, locked }: SubmissionFormProps) {
  const [text, setText] = useState(existing?.text_answer ?? "");
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const onSubmit = async () => {
    if (!text.trim() && !file && !existing?.file_path) {
      toast.error("Write an answer or attach a file.");
      return;
    }
    if (file) {
      if (file.size > MAX_SUBMISSION_FILE_BYTES) {
        toast.error("File is too large (max 10MB).");
        return;
      }
      if (!ALLOWED_SUBMISSION_MIME_TYPES.includes(file.type)) {
        toast.error("That file type isn't supported.");
        return;
      }
    }

    setSubmitting(true);
    let filePath = existing?.file_path ?? null;

    if (file) {
      const supabase = createClient();
      const safeName = file.name.replace(/[^a-zA-Z0-9_.-]/g, "_");
      const path = `${assignmentId}/${studentId}/${Date.now()}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from("assignment-submissions").upload(path, file, {
        upsert: true,
        contentType: file.type,
      });
      if (uploadError) {
        toast.error("File upload failed.");
        setSubmitting(false);
        return;
      }
      filePath = path;
    }

    const result = await submitAssignmentAction({ assignmentId, textAnswer: text, filePath });
    setSubmitting(false);

    if (result.error) {
      toast.error(result.error);
    } else {
      toast.success("Submission saved");
      router.refresh();
    }
  };

  return (
    <div className="space-y-3">
      <Textarea
        placeholder="Write your answer here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={4}
        disabled={locked}
      />
      <div className="flex flex-wrap items-center gap-3">
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          accept=".pdf,.doc,.docx,.zip,.png,.jpg,.jpeg,.txt"
          disabled={locked}
        />
        <Button type="button" variant="outline" size="sm" onClick={() => fileInputRef.current?.click()} disabled={locked}>
          <Paperclip className="h-4 w-4" />
          {file ? file.name : existing?.file_path ? "Replace file" : "Attach file"}
        </Button>
        <Button type="button" size="sm" onClick={onSubmit} disabled={submitting || locked}>
          {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
          {existing ? "Update submission" : "Submit"}
        </Button>
      </div>
    </div>
  );
}
