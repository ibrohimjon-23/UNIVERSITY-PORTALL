"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createAssignmentAction, updateAssignmentAction, type ActionResult } from "@/features/assignments/actions";
import type { Assignment, Group, Subject } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      {label}
    </Button>
  );
}

interface AssignmentFormDialogProps {
  assignment?: Assignment;
  groups: Group[];
  subjects: Subject[];
  lockedGroupId?: string;
}

export function AssignmentFormDialog({ assignment, groups, subjects, lockedGroupId }: AssignmentFormDialogProps) {
  const action = assignment ? updateAssignmentAction : createAssignmentAction;
  const [state, formAction] = useActionState(action, initial);
  const [open, setOpen] = useState(false);
  const [groupId, setGroupId] = useState(lockedGroupId ?? assignment?.group_id ?? groups[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState(assignment?.subject_id ?? subjects[0]?.id ?? "");
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success(assignment ? "Assignment updated" : "Assignment created");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) toast.error(state.error);
  }, [state, assignment, router]);

  const deadlineDefault = assignment ? new Date(assignment.deadline).toISOString().slice(0, 16) : "";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {assignment ? (
          <Button variant="ghost" size="icon" aria-label="Edit assignment">
            <Pencil className="h-4 w-4" />
          </Button>
        ) : (
          <Button>
            <Plus className="h-4 w-4" />
            New assignment
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{assignment ? "Edit assignment" : "Create assignment"}</DialogTitle>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {assignment ? <input type="hidden" name="id" value={assignment.id} /> : null}
          <div className="space-y-2">
            <Label htmlFor="title">Title</Label>
            <Input id="title" name="title" defaultValue={assignment?.title} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" name="description" defaultValue={assignment?.description ?? ""} rows={3} />
          </div>
          {!lockedGroupId ? (
            <div className="space-y-2">
              <Label>Group</Label>
              <input type="hidden" name="group_id" value={groupId} />
              <Select value={groupId} onValueChange={setGroupId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.group_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <input type="hidden" name="group_id" value={groupId} />
          )}
          <div className="space-y-2">
            <Label>Subject</Label>
            <input type="hidden" name="subject_id" value={subjectId} />
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="deadline">Deadline</Label>
            <Input id="deadline" name="deadline" type="datetime-local" defaultValue={deadlineDefault} required />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton label={assignment ? "Save changes" : "Create assignment"} />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
