"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { assignmentSchema, submissionSchema, reviewSubmissionSchema } from "@/validators/assignment";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export async function createAssignmentAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = assignmentSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description"),
    group_id: formData.get("group_id"),
    subject_id: formData.get("subject_id"),
    deadline: formData.get("deadline"),
  });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  if (actor.role === "leader" && parsed.data.group_id !== actor.group_id) {
    return { error: "You can only create assignments for your own group." };
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("assignments")
    .insert({
      title: parsed.data.title,
      description: parsed.data.description || null,
      group_id: parsed.data.group_id,
      subject_id: parsed.data.subject_id,
      deadline: new Date(parsed.data.deadline).toISOString(),
      created_by: actor.id,
    })
    .select()
    .single();

  if (error) return { error: "Could not create assignment." };

  await logAudit({ actorId: actor.id, action: "assignment.create", entityType: "assignment", entityId: data.id, newData: data });
  revalidatePath("/admin/assignments");
  revalidatePath("/leader/assignments");
  revalidatePath("/student/assignments");
  return { success: true };
}

export async function updateAssignmentAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const id = String(formData.get("id") ?? "");
  const parsed = assignmentSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description"),
    group_id: formData.get("group_id"),
    subject_id: formData.get("subject_id"),
    deadline: formData.get("deadline"),
  });
  if (!id || !parsed.success) return { error: parsed.success ? "Missing assignment id." : parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data: before } = await supabase.from("assignments").select("*").eq("id", id).maybeSingle();
  if (!before) return { error: "Assignment not found." };
  if (actor.role === "leader" && (before.group_id !== actor.group_id || parsed.data.group_id !== actor.group_id)) {
    return { error: "You can only manage assignments for your own group." };
  }

  const { data, error } = await supabase
    .from("assignments")
    .update({
      title: parsed.data.title,
      description: parsed.data.description || null,
      group_id: parsed.data.group_id,
      subject_id: parsed.data.subject_id,
      deadline: new Date(parsed.data.deadline).toISOString(),
    })
    .eq("id", id)
    .select()
    .single();

  if (error) return { error: "Could not update assignment." };

  await logAudit({ actorId: actor.id, action: "assignment.update", entityType: "assignment", entityId: id, oldData: before, newData: data });
  revalidatePath("/admin/assignments");
  revalidatePath("/leader/assignments");
  revalidatePath("/student/assignments");
  return { success: true };
}

export async function deleteAssignmentAction(id: string): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const supabase = await createClient();
  const { data: before } = await supabase.from("assignments").select("*").eq("id", id).maybeSingle();
  if (!before) return { error: "Assignment not found." };
  if (actor.role === "leader" && before.group_id !== actor.group_id) {
    return { error: "You can only manage assignments for your own group." };
  }

  const { error } = await supabase.from("assignments").delete().eq("id", id);
  if (error) return { error: "Could not delete assignment." };

  await logAudit({ actorId: actor.id, action: "assignment.delete", entityType: "assignment", entityId: id, oldData: before });
  revalidatePath("/admin/assignments");
  revalidatePath("/leader/assignments");
  revalidatePath("/student/assignments");
  return { success: true };
}

export async function submitAssignmentAction(input: {
  assignmentId: string;
  textAnswer: string;
  filePath: string | null;
}): Promise<ActionResult> {
  const student = await requireRole("student");
  const parsed = submissionSchema.safeParse({ assignment_id: input.assignmentId, text_answer: input.textAnswer });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };
  if (!parsed.data.text_answer && !input.filePath) {
    return { error: "Provide a text answer or attach a file." };
  }

  const supabase = await createClient();
  const { data: assignment } = await supabase.from("assignments").select("*").eq("id", parsed.data.assignment_id).maybeSingle();
  if (!assignment || assignment.group_id !== student.group_id) {
    return { error: "Assignment not found." };
  }

  const isLate = new Date() > new Date(assignment.deadline);
  const now = new Date().toISOString();

  const { error } = await supabase.from("assignment_submissions").upsert(
    {
      assignment_id: parsed.data.assignment_id,
      student_id: student.id,
      text_answer: parsed.data.text_answer || null,
      file_path: input.filePath,
      status: isLate ? "late" : "submitted",
      submitted_at: now,
    },
    { onConflict: "assignment_id,student_id" },
  );

  if (error) return { error: "Could not submit assignment." };

  await logAudit({
    actorId: student.id,
    action: "assignment.submit",
    entityType: "assignment_submission",
    entityId: parsed.data.assignment_id,
  });
  revalidatePath("/student/assignments");
  return { success: true };
}

export async function getSubmissionDownloadUrlAction(filePath: string): Promise<{ url?: string; error?: string }> {
  await requireRole("admin", "leader", "student");
  const supabase = await createClient();
  const { data, error } = await supabase.storage.from("assignment-submissions").createSignedUrl(filePath, 60);
  if (error || !data) return { error: "Could not generate a download link." };
  return { url: data.signedUrl };
}

export async function reviewSubmissionAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = reviewSubmissionSchema.safeParse({
    submission_id: formData.get("submission_id"),
    grade: formData.get("grade") || undefined,
    feedback: formData.get("feedback"),
  });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data: before } = await supabase.from("assignment_submissions").select("*").eq("id", parsed.data.submission_id).maybeSingle();
  if (!before) return { error: "Submission not found." };

  if (actor.role === "leader") {
    const { data: assignment } = await supabase.from("assignments").select("group_id").eq("id", before.assignment_id).maybeSingle();
    if (!assignment || assignment.group_id !== actor.group_id) {
      return { error: "You can only review submissions from your own group." };
    }
  }

  const { error } = await supabase
    .from("assignment_submissions")
    .update({
      grade: parsed.data.grade ?? null,
      feedback: parsed.data.feedback || null,
      status: "reviewed",
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", parsed.data.submission_id);

  if (error) return { error: "Could not save review." };

  await logAudit({
    actorId: actor.id,
    action: "assignment_submission.review",
    entityType: "assignment_submission",
    entityId: parsed.data.submission_id,
    oldData: before,
  });
  revalidatePath("/admin/assignments");
  revalidatePath("/leader/assignments");
  return { success: true };
}
