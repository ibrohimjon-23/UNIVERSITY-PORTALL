"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { toast } from "sonner";
import { CheckCheck, Megaphone, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { markNotificationReadAction, deleteNotificationAction } from "@/features/notifications/actions";
import type { NotificationRow } from "@/features/notifications/list-queries";

const TYPE_VARIANT = {
  info: "secondary",
  success: "success",
  warning: "warning",
  urgent: "destructive",
} as const;

export function NotificationList({ notifications, canDelete }: { notifications: NotificationRow[]; canDelete?: boolean }) {
  const router = useRouter();
  const [, startTransition] = useTransition();

  const markRead = (id: string) => {
    startTransition(async () => {
      const result = await markNotificationReadAction(id);
      if (result.error) toast.error(result.error);
      else router.refresh();
    });
  };

  if (notifications.length === 0) {
    return <EmptyState icon={Megaphone} title="No notifications" description="You're all caught up." />;
  }

  return (
    <div className="space-y-3">
      {notifications.map((n) => (
        <Card key={n.id} className={n.is_read ? "opacity-70" : "border-primary/40"}>
          <CardContent className="flex items-start justify-between gap-4 p-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <p className="font-medium">{n.title}</p>
                <Badge variant={TYPE_VARIANT[n.type]} className="capitalize">
                  {n.type}
                </Badge>
                {!n.is_read ? <span className="h-2 w-2 rounded-full bg-primary" aria-label="Unread" /> : null}
              </div>
              <p className="text-sm text-muted-foreground">{n.message}</p>
              <p className="text-xs text-muted-foreground">
                {n.sender_name ?? "System"} · {new Date(n.created_at).toLocaleString()}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1">
              {!n.is_read ? (
                <Button variant="ghost" size="icon" aria-label="Mark as read" onClick={() => markRead(n.id)}>
                  <CheckCheck className="h-4 w-4" />
                </Button>
              ) : null}
              {canDelete ? (
                <ConfirmDialog
                  trigger={
                    <Button variant="ghost" size="icon" aria-label="Delete notification">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  }
                  title="Delete notification?"
                  description="This removes it for everyone it was sent to."
                  onConfirm={async () => {
                    const result = await deleteNotificationAction(n.id);
                    if (result.error) toast.error(result.error);
                    else {
                      toast.success("Notification deleted");
                      router.refresh();
                    }
                  }}
                />
              ) : null}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
