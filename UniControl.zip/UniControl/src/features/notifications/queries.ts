import "server-only";
import { createClient } from "@/lib/supabase/server";

/** Accurate unread count via the fn_unread_notification_count() Postgres RPC. */
export async function getUnreadNotificationCount(): Promise<number> {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("fn_unread_notification_count");
  if (error || data == null) return 0;
  return data as number;
}
