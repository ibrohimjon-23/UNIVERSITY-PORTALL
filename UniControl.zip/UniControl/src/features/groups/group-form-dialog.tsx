"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createGroupAction, updateGroupAction, type ActionResult } from "@/features/groups/actions";
import type { Group } from "@/types/database";

const initial: ActionResult = {};

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      {label}
    </Button>
  );
}

export function GroupFormDialog({ group }: { group?: Group }) {
  const action = group ? updateGroupAction : createGroupAction;
  const [state, formAction] = useActionState(action, initial);
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success(group ? "Group updated" : "Group created");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) {
      toast.error(state.error);
    }
  }, [state, group, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {group ? (
          <Button variant="ghost" size="icon" aria-label="Edit group">
            <Pencil className="h-4 w-4" />
          </Button>
        ) : (
          <Button>
            <Plus className="h-4 w-4" />
            New group
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{group ? "Edit group" : "Create group"}</DialogTitle>
          <DialogDescription>
            {group ? "Update this group's details." : "Add a new group to the university."}
          </DialogDescription>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {group ? <input type="hidden" name="id" value={group.id} /> : null}
          <div className="space-y-2">
            <Label htmlFor="group_name">Group name</Label>
            <Input id="group_name" name="group_name" defaultValue={group?.group_name} required placeholder="CS-101" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="faculty">Faculty</Label>
              <Input id="faculty" name="faculty" defaultValue={group?.faculty} required placeholder="Computer Science" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="course">Course</Label>
              <Input id="course" name="course" type="number" min={1} max={8} defaultValue={group?.course ?? 1} required />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="year">Academic year</Label>
            <Input
              id="year"
              name="year"
              type="number"
              min={2000}
              max={2100}
              defaultValue={group?.year ?? new Date().getFullYear()}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" name="description" defaultValue={group?.description ?? ""} rows={3} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton label={group ? "Save changes" : "Create group"} />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
