"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { GroupFormDialog } from "@/features/groups/group-form-dialog";
import { AssignLeaderDialog } from "@/features/groups/assign-leader-dialog";
import { deleteGroupAction } from "@/features/groups/actions";
import type { Group, Profile } from "@/types/database";

export function GroupRowActions({ group, availableLeaders }: { group: Group; availableLeaders: Profile[] }) {
  const router = useRouter();

  return (
    <div className="flex items-center justify-end gap-1">
      <AssignLeaderDialog groupId={group.id} currentLeaderId={group.leader_id} availableLeaders={availableLeaders} />
      <GroupFormDialog group={group} />
      <ConfirmDialog
        trigger={
          <Button variant="ghost" size="icon" aria-label="Delete group">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        }
        title="Delete group?"
        description={`This will permanently delete "${group.group_name}". Groups with students, schedules or attendance records cannot be deleted.`}
        confirmLabel="Delete"
        onConfirm={async () => {
          const result = await deleteGroupAction(group.id);
          if (result.error) {
            toast.error(result.error);
          } else {
            toast.success("Group deleted");
            router.refresh();
          }
        }}
      />
    </div>
  );
}
