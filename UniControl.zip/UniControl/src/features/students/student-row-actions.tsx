"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { ResetPinDialog } from "@/components/shared/reset-pin-dialog";
import { StudentFormDialog } from "@/features/students/student-form-dialog";
import { deleteStudentAction, resetStudentPinAction } from "@/features/students/actions";
import type { Group, Profile } from "@/types/database";

interface StudentRowActionsProps {
  student: Profile;
  groups: Group[];
  lockedGroupId?: string;
  isAdmin: boolean;
}

export function StudentRowActions({ student, groups, lockedGroupId, isAdmin }: StudentRowActionsProps) {
  const router = useRouter();

  return (
    <div className="flex items-center justify-end gap-1">
      {isAdmin ? <ResetPinDialog userId={student.id} action={resetStudentPinAction} /> : null}
      <StudentFormDialog student={student} groups={groups} lockedGroupId={lockedGroupId} />
      {isAdmin ? (
        <ConfirmDialog
          trigger={
            <Button variant="ghost" size="icon" aria-label="Delete student">
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          }
          title="Delete student?"
          description={`This permanently deletes ${student.first_name} ${student.last_name}'s account and all their records.`}
          confirmLabel="Delete"
          onConfirm={async () => {
            const result = await deleteStudentAction(student.id);
            if (result.error) {
              toast.error(result.error);
            } else {
              toast.success("Student deleted");
              router.refresh();
            }
          }}
        />
      ) : null}
    </div>
  );
}
