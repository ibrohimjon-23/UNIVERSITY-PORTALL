import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { Group, Profile } from "@/types/database";

export interface StudentWithGroup extends Profile {
  group: Pick<Group, "id" | "group_name" | "faculty" | "course"> | null;
}

export interface ListStudentsParams {
  query?: string;
  groupId?: string;
  faculty?: string;
  course?: number;
  status?: "active" | "inactive";
  page?: number;
  pageSize?: number;
  /** Restrict results to this group regardless of other filters (leader scope). */
  scopeGroupId?: string;
}

export async function listStudents(params: ListStudentsParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 10;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let groupIdFilter: string[] | null = null;

  if (params.faculty || params.course) {
    let groupQuery = supabase.from("groups").select("id");
    if (params.faculty) groupQuery = groupQuery.eq("faculty", params.faculty);
    if (params.course) groupQuery = groupQuery.eq("course", params.course);
    const { data: groups } = await groupQuery;
    groupIdFilter = (groups ?? []).map((g) => g.id);
    if (groupIdFilter.length === 0) {
      return { rows: [] as StudentWithGroup[], total: 0, page, pageSize };
    }
  }

  let query = supabase.from("profiles").select("*", { count: "exact" }).eq("role", "student");

  if (params.scopeGroupId) {
    query = query.eq("group_id", params.scopeGroupId);
  } else if (params.groupId) {
    query = query.eq("group_id", params.groupId);
  } else if (groupIdFilter) {
    query = query.in("group_id", groupIdFilter);
  }

  if (params.status === "active") query = query.eq("is_active", true);
  if (params.status === "inactive") query = query.eq("is_active", false);

  if (params.query) {
    query = query.or(
      `first_name.ilike.%${params.query}%,last_name.ilike.%${params.query}%,username.ilike.%${params.query}%,student_id.ilike.%${params.query}%`,
    );
  }

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const rows = await attachGroups((data ?? []) as Profile[]);
  return { rows, total: count ?? 0, page, pageSize };
}

async function attachGroups(students: Profile[]): Promise<StudentWithGroup[]> {
  if (students.length === 0) return [];
  const supabase = await createClient();
  const groupIds = Array.from(new Set(students.map((s) => s.group_id).filter(Boolean))) as string[];
  if (groupIds.length === 0) return students.map((s) => ({ ...s, group: null }));

  const { data: groups } = await supabase.from("groups").select("id, group_name, faculty, course").in("id", groupIds);
  const byId = new Map((groups ?? []).map((g) => [g.id, g]));
  return students.map((s) => ({ ...s, group: s.group_id ? byId.get(s.group_id) ?? null : null }));
}

export async function listAllStudentsLite(): Promise<Profile[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("profiles").select("*").eq("role", "student").eq("is_active", true).order("first_name");
  if (error) throw error;
  return data as Profile[];
}

export async function listGroupStudentsLite(groupId: string): Promise<Profile[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("role", "student")
    .eq("group_id", groupId)
    .eq("is_active", true)
    .order("first_name");
  if (error) throw error;
  return data as Profile[];
}

export async function getStudentById(id: string): Promise<StudentWithGroup | null> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("profiles").select("*").eq("id", id).eq("role", "student").maybeSingle();
  if (error || !data) return null;
  const [withGroup] = await attachGroups([data as Profile]);
  return withGroup ?? null;
}
