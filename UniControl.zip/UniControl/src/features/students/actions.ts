"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireRole, usernameToAuthEmail } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { createStudentSchema, updateStudentSchema } from "@/validators/profile";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

/** Admins may create a student in any group; leaders only in their own assigned group. */
export async function createStudentAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = createStudentSchema.safeParse({
    first_name: formData.get("first_name"),
    last_name: formData.get("last_name"),
    username: formData.get("username"),
    pin: formData.get("pin"),
    student_id: formData.get("student_id"),
    group_id: formData.get("group_id"),
    phone: formData.get("phone"),
    email: formData.get("email"),
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  if (actor.role === "leader" && parsed.data.group_id !== actor.group_id) {
    return { error: "You can only add students to your own group." };
  }

  const adminClient = createAdminClient();
  const email = usernameToAuthEmail(parsed.data.username);

  const { data: created, error: createError } = await adminClient.auth.admin.createUser({
    email,
    password: parsed.data.pin,
    email_confirm: true,
    user_metadata: { role: "student", username: parsed.data.username },
  });

  if (createError || !created.user) {
    return {
      error: createError?.message.includes("already been registered")
        ? "That username is already taken."
        : "Could not create the student account.",
    };
  }

  const supabase = await createClient();
  const { error: profileError } = await supabase.from("profiles").insert({
    id: created.user.id,
    role: "student",
    username: parsed.data.username,
    first_name: parsed.data.first_name,
    last_name: parsed.data.last_name,
    student_id: parsed.data.student_id,
    group_id: parsed.data.group_id,
    phone: parsed.data.phone || null,
    email: parsed.data.email || null,
    is_active: true,
  });

  if (profileError) {
    await adminClient.auth.admin.deleteUser(created.user.id);
    return {
      error: profileError.code === "23505" ? "That student ID is already in use." : "Could not create the student profile.",
    };
  }

  await logAudit({
    actorId: actor.id,
    action: "student.create",
    entityType: "profile",
    entityId: created.user.id,
    newData: { username: parsed.data.username, group_id: parsed.data.group_id },
  });

  revalidatePath("/admin/students");
  revalidatePath("/leader/group");
  return { success: true };
}

export async function updateStudentAction(_prev: ActionResult, formData: FormData): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = updateStudentSchema.safeParse({
    id: formData.get("id"),
    first_name: formData.get("first_name"),
    last_name: formData.get("last_name"),
    student_id: formData.get("student_id"),
    group_id: formData.get("group_id"),
    phone: formData.get("phone"),
    email: formData.get("email"),
    is_active: formData.get("is_active") === "true",
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Invalid input." };
  }

  const supabase = await createClient();
  const { data: before } = await supabase.from("profiles").select("*").eq("id", parsed.data.id).maybeSingle();

  if (!before || before.role !== "student") return { error: "Student not found." };
  if (actor.role === "leader" && (before.group_id !== actor.group_id || parsed.data.group_id !== actor.group_id)) {
    return { error: "You can only manage students in your own group." };
  }

  const { error } = await supabase
    .from("profiles")
    .update({
      first_name: parsed.data.first_name,
      last_name: parsed.data.last_name,
      student_id: parsed.data.student_id,
      group_id: parsed.data.group_id,
      phone: parsed.data.phone || null,
      email: parsed.data.email || null,
      is_active: actor.role === "admin" ? parsed.data.is_active : before.is_active,
    })
    .eq("id", parsed.data.id);

  if (error) {
    return { error: error.code === "23505" ? "That student ID is already in use." : "Could not update student." };
  }

  await logAudit({
    actorId: actor.id,
    action: "student.update",
    entityType: "profile",
    entityId: parsed.data.id,
    oldData: before,
  });
  revalidatePath("/admin/students");
  revalidatePath("/leader/group");
  return { success: true };
}

export async function resetStudentPinAction(studentId: string, newPin: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  if (!/^[0-9]{4,64}$/.test(newPin)) return { error: "PIN must be numeric, at least 4 digits." };

  const adminClient = createAdminClient();
  const { error } = await adminClient.auth.admin.updateUserById(studentId, { password: newPin });
  if (error) return { error: "Could not reset PIN." };

  await logAudit({ actorId: admin.id, action: "student.reset_pin", entityType: "profile", entityId: studentId });
  return { success: true };
}

export async function deleteStudentAction(studentId: string): Promise<ActionResult> {
  const admin = await requireRole("admin");
  const supabase = await createClient();
  const { data: before } = await supabase.from("profiles").select("*").eq("id", studentId).maybeSingle();

  const adminClient = createAdminClient();
  const { error } = await adminClient.auth.admin.deleteUser(studentId);
  if (error) return { error: "Could not delete student." };

  await logAudit({ actorId: admin.id, action: "student.delete", entityType: "profile", entityId: studentId, oldData: before });
  revalidatePath("/admin/students");
  revalidatePath("/leader/group");
  return { success: true };
}
