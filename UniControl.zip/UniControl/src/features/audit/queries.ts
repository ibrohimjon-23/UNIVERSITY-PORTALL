import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { AuditLog, Profile } from "@/types/database";

export interface AuditLogRow extends AuditLog {
  actor: Pick<Profile, "id" | "first_name" | "last_name" | "username" | "role"> | null;
}

export interface ListAuditLogsParams {
  query?: string;
  entityType?: string;
  page?: number;
  pageSize?: number;
}

export async function listAuditLogs(params: ListAuditLogsParams) {
  const supabase = await createClient();
  const page = params.page ?? 1;
  const pageSize = params.pageSize ?? 20;
  const from = (page - 1) * pageSize;
  const to = from + pageSize - 1;

  let query = supabase.from("audit_logs").select("*", { count: "exact" });
  if (params.entityType) query = query.eq("entity_type", params.entityType);
  if (params.query) query = query.ilike("action", `%${params.query}%`);

  const { data, count, error } = await query.order("created_at", { ascending: false }).range(from, to);
  if (error) throw error;

  const logs = (data ?? []) as AuditLog[];
  const actorIds = Array.from(new Set(logs.map((l) => l.actor_id).filter(Boolean))) as string[];
  const { data: actors } = actorIds.length
    ? await supabase.from("profiles").select("id, first_name, last_name, username, role").in("id", actorIds)
    : { data: [] };
  const actorById = new Map((actors ?? []).map((a) => [a.id, a]));

  const rows: AuditLogRow[] = logs.map((l) => ({ ...l, actor: l.actor_id ? actorById.get(l.actor_id) ?? null : null }));
  return { rows, total: count ?? 0, page, pageSize };
}

export async function getDistinctEntityTypes(): Promise<string[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("audit_logs").select("entity_type");
  return Array.from(new Set((data ?? []).map((r) => r.entity_type))).sort();
}
