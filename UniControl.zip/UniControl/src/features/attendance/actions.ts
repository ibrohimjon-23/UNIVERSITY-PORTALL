"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";
import { logAudit } from "@/lib/audit";
import { createAttendanceSessionSchema, submitAttendanceSchema, manualAttendanceOverrideSchema } from "@/validators/attendance";
import { getUniversitySettings } from "@/features/settings/queries";

export interface ActionResult {
  error?: string;
  success?: boolean;
}

export interface CreateSessionResult extends ActionResult {
  sessionId?: string;
}

/** Admin can start a session for any group; leaders only for their own. */
export async function createAttendanceSessionAction(
  _prev: CreateSessionResult,
  formData: FormData,
): Promise<CreateSessionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = createAttendanceSessionSchema.safeParse({
    group_id: formData.get("group_id"),
    subject_id: formData.get("subject_id"),
    teacher_id: formData.get("teacher_id"),
    schedule_id: formData.get("schedule_id"),
    duration_minutes: formData.get("duration_minutes"),
  });

  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  if (actor.role === "leader" && parsed.data.group_id !== actor.group_id) {
    return { error: "You can only start attendance sessions for your own group." };
  }

  const settings = await getUniversitySettings();
  const now = new Date();
  const endTime = new Date(now.getTime() + parsed.data.duration_minutes * 60_000);
  const qrExpiresAt = new Date(now.getTime() + settings.qr_expiry_seconds * 1000);

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("attendance_sessions")
    .insert({
      group_id: parsed.data.group_id,
      subject_id: parsed.data.subject_id,
      teacher_id: parsed.data.teacher_id || null,
      schedule_id: parsed.data.schedule_id || null,
      session_date: now.toISOString().slice(0, 10),
      start_time: now.toISOString(),
      end_time: endTime.toISOString(),
      status: "active",
      qr_expires_at: qrExpiresAt.toISOString(),
      created_by: actor.id,
    })
    .select()
    .single();

  if (error) return { error: "Could not start attendance session." };

  await logAudit({
    actorId: actor.id,
    action: "attendance_session.create",
    entityType: "attendance_session",
    entityId: data.id,
    newData: data,
  });

  revalidatePath("/admin/attendance");
  revalidatePath("/leader/attendance");
  return { success: true, sessionId: data.id };
}

export interface RotateQrResult extends ActionResult {
  qrToken?: string;
  qrExpiresAt?: string;
}

export async function rotateQrAction(sessionId: string): Promise<RotateQrResult> {
  await requireRole("admin", "leader");
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("fn_rotate_qr", { p_session_id: sessionId }).single();
  if (error) return { error: error.message };
  const row = data as { qr_token: string; qr_expires_at: string };
  return { success: true, qrToken: row.qr_token, qrExpiresAt: row.qr_expires_at };
}

export async function closeAttendanceSessionAction(sessionId: string): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const supabase = await createClient();
  const { error } = await supabase.rpc("fn_close_attendance_session", { p_session_id: sessionId });
  if (error) return { error: error.message };

  await logAudit({ actorId: actor.id, action: "attendance_session.close", entityType: "attendance_session", entityId: sessionId });
  revalidatePath("/admin/attendance");
  revalidatePath("/leader/attendance");
  return { success: true };
}

export interface SubmitAttendanceResult extends ActionResult {
  status?: string;
  message?: string;
  distanceMeters?: number;
}

export async function submitAttendanceAction(input: {
  sessionId: string;
  qrToken: string;
  latitude: number;
  longitude: number;
  accuracy: number | null;
}): Promise<SubmitAttendanceResult> {
  await requireRole("student");
  const parsed = submitAttendanceSchema.safeParse({
    session_id: input.sessionId,
    qr_token: input.qrToken,
    latitude: input.latitude,
    longitude: input.longitude,
    accuracy: input.accuracy,
  });

  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data, error } = await supabase
    .rpc("fn_submit_attendance", {
      p_session_id: parsed.data.session_id,
      p_qr_token: parsed.data.qr_token,
      p_latitude: parsed.data.latitude,
      p_longitude: parsed.data.longitude,
      p_accuracy: parsed.data.accuracy ?? null,
    })
    .single();

  if (error) return { error: "Could not submit attendance. Please try again." };

  const row = data as { ok: boolean; status: string | null; message: string; distance_m: number | null };
  if (!row.ok) return { error: row.message, distanceMeters: row.distance_m ?? undefined };

  revalidatePath("/student/attendance");
  return { success: true, status: row.status ?? undefined, message: row.message, distanceMeters: row.distance_m ?? undefined };
}

export async function manualAttendanceOverrideAction(input: {
  studentId: string;
  attendanceSessionId: string;
  status: "present" | "absent" | "late" | "excused";
}): Promise<ActionResult> {
  const actor = await requireRole("admin", "leader");
  const parsed = manualAttendanceOverrideSchema.safeParse({
    student_id: input.studentId,
    attendance_session_id: input.attendanceSessionId,
    status: input.status,
  });
  if (!parsed.success) return { error: parsed.error.issues[0]?.message };

  const supabase = await createClient();
  const { data: session } = await supabase
    .from("attendance_sessions")
    .select("*")
    .eq("id", parsed.data.attendance_session_id)
    .maybeSingle();
  if (!session) return { error: "Session not found." };
  if (actor.role === "leader" && session.group_id !== actor.group_id) {
    return { error: "You can only manage attendance for your own group." };
  }

  const { data: existing } = await supabase
    .from("attendance_records")
    .select("id")
    .eq("student_id", parsed.data.student_id)
    .eq("attendance_session_id", parsed.data.attendance_session_id)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase.from("attendance_records").update({ status: parsed.data.status }).eq("id", existing.id);
    if (error) return { error: "Could not update attendance record." };
  } else {
    const { error } = await supabase.from("attendance_records").insert({
      student_id: parsed.data.student_id,
      group_id: session.group_id,
      subject_id: session.subject_id,
      attendance_session_id: parsed.data.attendance_session_id,
      status: parsed.data.status,
      verification_method: "manual",
    });
    if (error) return { error: "Could not create attendance record." };
  }

  await logAudit({
    actorId: actor.id,
    action: "attendance_record.override",
    entityType: "attendance_record",
    entityId: parsed.data.student_id,
    newData: parsed.data,
  });

  revalidatePath("/admin/attendance");
  revalidatePath("/leader/attendance");
  return { success: true };
}
