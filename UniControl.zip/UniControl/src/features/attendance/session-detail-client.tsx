"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { StopCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { closeAttendanceSessionAction, manualAttendanceOverrideAction } from "@/features/attendance/actions";
import type { RecordWithStudent } from "@/features/attendance/queries";
import type { AttendanceSession, AttendanceStatus, Profile } from "@/types/database";

const STATUS_OPTIONS: AttendanceStatus[] = ["present", "late", "absent", "excused"];
const STATUS_VARIANT: Record<AttendanceStatus, "success" | "warning" | "destructive" | "secondary"> = {
  present: "success",
  late: "warning",
  absent: "destructive",
  excused: "secondary",
};

interface SessionDetailClientProps {
  session: AttendanceSession;
  records: RecordWithStudent[];
  groupStudents: Profile[];
}

export function SessionDetailClient({ session, records, groupStudents }: SessionDetailClientProps) {
  const router = useRouter();
  const recordByStudent = new Map(records.map((r) => [r.student_id, r]));

  const updateStatus = async (studentId: string, status: AttendanceStatus) => {
    const result = await manualAttendanceOverrideAction({ studentId, attendanceSessionId: session.id, status });
    if (result.error) toast.error(result.error);
    else {
      toast.success("Attendance updated");
      router.refresh();
    }
  };

  const closeSession = async () => {
    const result = await closeAttendanceSessionAction(session.id);
    if (result.error) toast.error(result.error);
    else {
      toast.success("Session closed");
      router.refresh();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Badge variant={session.status === "active" ? "success" : "secondary"} className="capitalize">
            {session.status}
          </Badge>
          <span className="text-sm text-muted-foreground">
            {new Date(session.start_time).toLocaleString()} – {new Date(session.end_time).toLocaleTimeString()}
          </span>
        </div>
        {session.status === "active" ? (
          <ConfirmDialog
            trigger={
              <Button variant="outline" size="sm">
                <StopCircle className="h-4 w-4" />
                End session
              </Button>
            }
            title="End this attendance session?"
            description="Students who haven't checked in will be marked absent. This cannot be undone."
            confirmLabel="End session"
            onConfirm={closeSession}
          />
        ) : null}
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Student</TableHead>
            <TableHead>Student ID</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Distance</TableHead>
            <TableHead>Checked in</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {groupStudents.map((student) => {
            const record = recordByStudent.get(student.id);
            return (
              <TableRow key={student.id}>
                <TableCell className="font-medium">
                  {student.first_name} {student.last_name}
                </TableCell>
                <TableCell>{student.student_id}</TableCell>
                <TableCell>
                  <Select value={record?.status ?? "absent"} onValueChange={(v) => updateStatus(student.id, v as AttendanceStatus)}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map((s) => (
                        <SelectItem key={s} value={s}>
                          <Badge variant={STATUS_VARIANT[s]} className="capitalize">
                            {s}
                          </Badge>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>{record?.distance_from_university != null ? `${Math.round(record.distance_from_university)}m` : "—"}</TableCell>
                <TableCell>{record ? new Date(record.checked_at).toLocaleTimeString() : "—"}</TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
