"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { Loader2, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { generateQrDataUrl } from "@/lib/qr";
import { rotateQrAction } from "@/features/attendance/actions";

interface QrDisplayProps {
  sessionId: string;
  initialToken: string;
  initialExpiresAt: string;
}

export function QrDisplay({ sessionId, initialToken, initialExpiresAt }: QrDisplayProps) {
  const [token, setToken] = useState(initialToken);
  const [expiresAt, setExpiresAt] = useState(initialExpiresAt);
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const rotatingRef = useRef(false);

  const rotate = useCallback(async () => {
    if (rotatingRef.current) return;
    rotatingRef.current = true;
    const result = await rotateQrAction(sessionId);
    rotatingRef.current = false;
    if (result.error || !result.qrToken || !result.qrExpiresAt) {
      toast.error(result.error ?? "Could not refresh QR code.");
      return;
    }
    setToken(result.qrToken);
    setExpiresAt(result.qrExpiresAt);
  }, [sessionId]);

  useEffect(() => {
    generateQrDataUrl({ sessionId, token }).then(setDataUrl);
  }, [sessionId, token]);

  useEffect(() => {
    const interval = setInterval(() => {
      const remaining = Math.max(0, Math.round((new Date(expiresAt).getTime() - Date.now()) / 1000));
      setSecondsLeft(remaining);
      if (remaining <= 0) rotate();
    }, 1000);
    return () => clearInterval(interval);
  }, [expiresAt, rotate]);

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="rounded-xl border bg-white p-4 shadow-sm">
        {dataUrl ? (
          <Image src={dataUrl} alt="Attendance QR code" width={280} height={280} unoptimized />
        ) : (
          <div className="flex h-[280px] w-[280px] items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}
      </div>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span>Refreshes in {secondsLeft}s</span>
        <Button variant="ghost" size="icon" onClick={rotate} aria-label="Refresh now">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>
      <p className="max-w-sm text-center text-xs text-muted-foreground">
        Students must scan this code and be within the campus geofence to be marked present.
        The code rotates automatically and cannot be reused.
      </p>
    </div>
  );
}
