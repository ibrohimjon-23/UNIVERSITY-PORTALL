"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import { Loader2, Pencil, Plus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { createScheduleAction, updateScheduleAction, type ActionResult } from "@/features/schedules/actions";
import { dayName } from "@/lib/utils";
import type { Group, Schedule, Subject, Teacher } from "@/types/database";

const initial: ActionResult = {};
const DAYS = [1, 2, 3, 4, 5, 6, 0];

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
      {label}
    </Button>
  );
}

interface ScheduleFormDialogProps {
  schedule?: Schedule;
  groups: Group[];
  subjects: Subject[];
  teachers: Teacher[];
  lockedGroupId?: string;
}

export function ScheduleFormDialog({ schedule, groups, subjects, teachers, lockedGroupId }: ScheduleFormDialogProps) {
  const action = schedule ? updateScheduleAction : createScheduleAction;
  const [state, formAction] = useActionState(action, initial);
  const [open, setOpen] = useState(false);
  const [groupId, setGroupId] = useState(lockedGroupId ?? schedule?.group_id ?? groups[0]?.id ?? "");
  const [subjectId, setSubjectId] = useState(schedule?.subject_id ?? subjects[0]?.id ?? "");
  const [teacherId, setTeacherId] = useState(schedule?.teacher_id ?? "");
  const [day, setDay] = useState(String(schedule?.day_of_week ?? 1));
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.success) {
      toast.success(schedule ? "Schedule updated" : "Schedule created");
      setOpen(false);
      formRef.current?.reset();
      router.refresh();
    } else if (state.error) {
      toast.error(state.error);
    }
  }, [state, schedule, router]);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {schedule ? (
          <Button variant="ghost" size="icon" aria-label="Edit schedule entry">
            <Pencil className="h-4 w-4" />
          </Button>
        ) : (
          <Button>
            <Plus className="h-4 w-4" />
            Add class
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{schedule ? "Edit class" : "Add class"}</DialogTitle>
          <DialogDescription>Schedule a recurring weekly class for a group.</DialogDescription>
        </DialogHeader>
        <form ref={formRef} action={formAction} className="space-y-4">
          {schedule ? <input type="hidden" name="id" value={schedule.id} /> : null}
          {!lockedGroupId ? (
            <div className="space-y-2">
              <Label>Group</Label>
              <input type="hidden" name="group_id" value={groupId} />
              <Select value={groupId} onValueChange={setGroupId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a group" />
                </SelectTrigger>
                <SelectContent>
                  {groups.map((g) => (
                    <SelectItem key={g.id} value={g.id}>
                      {g.group_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <input type="hidden" name="group_id" value={groupId} />
          )}
          <div className="space-y-2">
            <Label>Subject</Label>
            <input type="hidden" name="subject_id" value={subjectId} />
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Teacher</Label>
            <input type="hidden" name="teacher_id" value={teacherId} />
            <Select value={teacherId || "none"} onValueChange={(v) => setTeacherId(v === "none" ? "" : v)}>
              <SelectTrigger>
                <SelectValue placeholder="No teacher" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No teacher</SelectItem>
                {teachers.map((t) => (
                  <SelectItem key={t.id} value={t.id}>
                    {t.first_name} {t.last_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Day</Label>
              <input type="hidden" name="day_of_week" value={day} />
              <Select value={day} onValueChange={setDay}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DAYS.map((d) => (
                    <SelectItem key={d} value={String(d)}>
                      {dayName(d)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="room">Room</Label>
              <Input id="room" name="room" defaultValue={schedule?.room} required placeholder="205" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="start_time">Start time</Label>
              <Input id="start_time" name="start_time" type="time" defaultValue={schedule?.start_time?.slice(0, 5)} required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end_time">End time</Label>
              <Input id="end_time" name="end_time" type="time" defaultValue={schedule?.end_time?.slice(0, 5)} required />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton label={schedule ? "Save changes" : "Add class"} />
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
