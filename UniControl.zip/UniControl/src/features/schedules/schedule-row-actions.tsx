"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { ScheduleFormDialog } from "@/features/schedules/schedule-form-dialog";
import { deleteScheduleAction } from "@/features/schedules/actions";
import type { ScheduleWithRelations } from "@/features/schedules/queries";
import type { Group, Subject, Teacher } from "@/types/database";

interface ScheduleRowActionsProps {
  schedule: ScheduleWithRelations;
  groups: Group[];
  subjects: Subject[];
  teachers: Teacher[];
  lockedGroupId?: string;
}

export function ScheduleRowActions({ schedule, groups, subjects, teachers, lockedGroupId }: ScheduleRowActionsProps) {
  const router = useRouter();

  return (
    <div className="flex items-center gap-1">
      <ScheduleFormDialog schedule={schedule} groups={groups} subjects={subjects} teachers={teachers} lockedGroupId={lockedGroupId} />
      <ConfirmDialog
        trigger={
          <Button variant="ghost" size="icon" aria-label="Delete class">
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        }
        title="Delete this class?"
        description="This removes it from the group's weekly timetable."
        onConfirm={async () => {
          const result = await deleteScheduleAction(schedule.id);
          if (result.error) toast.error(result.error);
          else {
            toast.success("Class removed");
            router.refresh();
          }
        }}
      />
    </div>
  );
}
