# UniControl

A production-quality university management platform: groups, leaders, students,
schedules, geofenced + QR-verified attendance, assignments, notifications,
audit logs and admin settings — all backed by a real PostgreSQL/Supabase
database with Row Level Security, not mock data.

## Tech stack

- **Frontend:** Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS,
  Radix UI primitives (shadcn-style components), Lucide icons, Recharts
- **Backend:** Next.js Server Actions + Postgres RPC functions (SECURITY
  DEFINER) for security-critical logic (attendance geofencing/QR, leader
  assignment, dashboard stats)
- **Database/Auth/Storage:** Supabase (PostgreSQL, Auth, Storage)
- **Validation:** Zod
- **Testing:** Vitest

## Project structure

```text
src/
├── app/                # Next.js App Router routes, grouped by role
│   ├── admin/          # Admin dashboard, groups, students, leaders,
│   │                   # schedule, attendance, assignments, notifications,
│   │                   # audit log, settings
│   ├── leader/         # Leader dashboard, own-group management
│   ├── student/        # Student dashboard, attendance check-in, assignments
│   └── login/          # Username + PIN sign-in
├── components/
│   ├── ui/             # Reusable primitives (button, dialog, table, ...)
│   ├── shared/         # App-level shared components (search, pagination,
│   │                   # QR scanner, empty/error states, confirm dialog, ...)
│   └── layout/         # Sidebar, navbar, app shell, nav config
├── features/           # Domain logic, grouped by feature: queries.ts
│                        # (data fetching) + actions.ts (Server Actions) +
│                        # feature-specific UI (dialogs, forms, lists)
├── hooks/               # Client hooks (debounce)
├── lib/                 # Supabase clients, auth helpers, geo/QR/audit utils
├── types/               # Hand-written row/enum types matching the schema
├── validators/           # Zod schemas for every mutating action
└── middleware.ts         # Session refresh + role-based route protection

supabase/migrations/0001_init.sql   # Full schema, RLS policies, SQL functions
scripts/seed.ts                     # Development seed data
tests/                              # Vitest unit tests
```

## Getting started

### 1. Create a Supabase project

Create a project at [supabase.com](https://supabase.com), then open the SQL
editor and run the entire contents of `supabase/migrations/0001_init.sql`.
This creates every table, enum, index, RLS policy, storage bucket and SQL
function (including the geofence/QR attendance logic).

### 2. Configure environment variables

```bash
cp .env.example .env.local
```

Fill in `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` and
`SUPABASE_SERVICE_ROLE_KEY` from your Supabase project's API settings
(Project Settings → API). **Never commit `.env.local` or the service role
key.**

### 3. Install dependencies

```bash
npm install
```

### 4. Seed development data (optional but recommended)

```bash
npm run seed
```

Creates 1 admin, 2 leaders, 3 groups, 12 students, subjects, teachers and a
weekly schedule. Default PIN for every seeded account is `123456`. Sign in
with `admin`, `leader.cs101`, `leader.cs201`, or `student1`–`student12`.

### 5. Run the app

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### Other scripts

```bash
npm run build       # production build
npm run lint         # ESLint
npm run typecheck    # tsc --noEmit
npm test             # vitest run
```

## Attendance: geofencing + QR verification

- University location and radius are configurable at **Admin → Settings**
  (defaults: lat `40.785444`, lng `72.352389`, radius `200m`).
- A leader or admin starts an **attendance session** for a class, which
  generates a QR code that **rotates every `qr_expiry_seconds`** (default 45s).
- A student clicks **Check Attendance**, grants location permission, then
  scans the projected QR code with their camera (no third-party scanning
  service — pure `getUserMedia` + `jsQR` on the client).
- The scanned session ID + QR token and the device's coordinates are sent to
  the `fn_submit_attendance` Postgres function, which **independently**
  re-verifies: the caller is an active student, belongs to the session's
  group, the session is active and within its time window, the QR token
  matches and hasn't expired, the coordinates are valid, accuracy is
  acceptable, the student hasn't already checked in (unique constraint), and
  the Haversine distance to the university is within the configured radius.
  Only then is an attendance record inserted. The frontend's own distance
  calculation is display-only and never trusted for the actual decision.

## Security notes

- Row Level Security is enabled on every table. Admins have full access;
  leaders are confined to their own group via a `leads_group()` policy
  helper; students can only read their own data and their group's shared
  data. This is enforced by Postgres itself, not just hidden in the UI.
- Students and leaders authenticate with a username + PIN, which is mapped
  to a synthetic internal email and handled entirely by Supabase Auth
  (GoTrue) — PINs are bcrypt-hashed by Supabase, never stored or handled in
  application code.
- Privileged operations (creating auth accounts, resetting PINs) run through
  a service-role client that is only ever imported in server-only code
  (`lib/supabase/admin.ts`, marked with the `server-only` package) and is
  never reachable from the browser.
- File uploads (assignment submissions, avatars) go to private Supabase
  Storage buckets with RLS policies scoping access by folder path.

## Known limitations

- PWA icons are SVG placeholders (`public/icons/icon.svg`); supply real PNG
  icons for full iOS "Add to Home Screen" support.
- The schema and RLS policies were validated with static analysis and unit
  tests in this environment (no live Postgres instance was available while
  building); run the migration against a real Supabase project and smoke
  test the attendance flow before production use.
