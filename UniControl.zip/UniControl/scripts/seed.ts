/**
 * Development seed script — creates sample data via the Supabase Admin API.
 * Run with: npm run seed
 * Requires NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (loaded
 * from .env.local when present). Never run this against production.
 */
try {
  process.loadEnvFile(".env.local");
} catch {
  // .env.local not present; assume env vars are already set (e.g. in CI).
}

import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const AUTH_DOMAIN = process.env.AUTH_USERNAME_DOMAIN || "unicontrol.internal";

if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
  console.error("Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY.");
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

function emailFor(username: string) {
  return `${username}@${AUTH_DOMAIN}`;
}

async function createUser(params: {
  username: string;
  pin: string;
  role: "admin" | "leader" | "student";
  first_name: string;
  last_name: string;
  student_id?: string;
  group_id?: string | null;
  phone?: string;
}) {
  const email = emailFor(params.username);
  const { data: created, error } = await supabase.auth.admin.createUser({
    email,
    password: params.pin,
    email_confirm: true,
    user_metadata: { role: params.role, username: params.username },
  });

  if (error || !created.user) {
    if (error?.message.includes("already been registered")) {
      console.log(`  skip: ${params.username} already exists`);
      const { data: existing } = await supabase.auth.admin.listUsers();
      const match = existing.users.find((u) => u.email === email);
      return match?.id ?? null;
    }
    console.error(`  failed to create ${params.username}:`, error?.message);
    return null;
  }

  const { error: profileError } = await supabase.from("profiles").insert({
    id: created.user.id,
    role: params.role,
    username: params.username,
    first_name: params.first_name,
    last_name: params.last_name,
    student_id: params.student_id ?? null,
    group_id: params.group_id ?? null,
    phone: params.phone ?? null,
    is_active: true,
  });

  if (profileError) {
    console.error(`  failed to insert profile for ${params.username}:`, profileError.message);
    await supabase.auth.admin.deleteUser(created.user.id);
    return null;
  }

  console.log(`  created: ${params.username} (${params.role})`);
  return created.user.id;
}

async function main() {
  console.log("Seeding UniControl development data...\n");

  console.log("Admin:");
  await createUser({ username: "admin", pin: "123456", role: "admin", first_name: "Alice", last_name: "Admin" });

  console.log("\nGroups:");
  const groupDefs = [
    { group_name: "CS-101", faculty: "Computer Science", course: 1, year: 2025 },
    { group_name: "CS-201", faculty: "Computer Science", course: 2, year: 2024 },
    { group_name: "ECON-101", faculty: "Economics", course: 1, year: 2025 },
  ];
  const groupIds: string[] = [];
  for (const g of groupDefs) {
    const { data: existing } = await supabase.from("groups").select("id").eq("group_name", g.group_name).maybeSingle();
    if (existing) {
      groupIds.push(existing.id);
      console.log(`  skip: ${g.group_name} already exists`);
      continue;
    }
    const { data, error } = await supabase.from("groups").insert(g).select().single();
    if (error || !data) {
      console.error(`  failed to create group ${g.group_name}:`, error?.message);
      continue;
    }
    groupIds.push(data.id);
    console.log(`  created: ${g.group_name}`);
  }

  console.log("\nSubjects:");
  const subjectDefs = [
    { name: "Programming Fundamentals", code: "CS101" },
    { name: "Data Structures", code: "CS201" },
    { name: "Calculus I", code: "MATH101" },
    { name: "Microeconomics", code: "ECON101" },
  ];
  const subjectIds: string[] = [];
  for (const s of subjectDefs) {
    const { data: existing } = await supabase.from("subjects").select("id").eq("code", s.code).maybeSingle();
    if (existing) {
      subjectIds.push(existing.id);
      continue;
    }
    const { data, error } = await supabase.from("subjects").insert(s).select().single();
    if (!error && data) subjectIds.push(data.id);
  }
  console.log(`  ${subjectIds.length} subjects ready`);

  console.log("\nTeachers:");
  const teacherDefs = [
    { first_name: "John", last_name: "Carter", email: "j.carter@example.edu" },
    { first_name: "Maria", last_name: "Lopez", email: "m.lopez@example.edu" },
  ];
  const teacherIds: string[] = [];
  for (const t of teacherDefs) {
    const { data: existing } = await supabase.from("teachers").select("id").eq("email", t.email).maybeSingle();
    if (existing) {
      teacherIds.push(existing.id);
      continue;
    }
    const { data, error } = await supabase.from("teachers").insert(t).select().single();
    if (!error && data) teacherIds.push(data.id);
  }
  console.log(`  ${teacherIds.length} teachers ready`);

  console.log("\nLeaders:");
  const leaderIds: string[] = [];
  const leaderDefs = [
    { username: "leader.cs101", pin: "123456", first_name: "Diyor", last_name: "Yusupov", group_id: groupIds[0] },
    { username: "leader.cs201", pin: "123456", first_name: "Nilufar", last_name: "Rashidova", group_id: groupIds[1] },
  ];
  for (const l of leaderDefs) {
    const id = await createUser({ username: l.username, pin: l.pin, role: "leader", first_name: l.first_name, last_name: l.last_name });
    if (id && l.group_id) {
      await supabase.rpc("fn_assign_leader", { p_group_id: l.group_id, p_leader_id: id }).then(({ error }) => {
        if (error) console.error(`  failed to assign leader ${l.username}:`, error.message);
      });
      leaderIds.push(id);
    }
  }

  console.log("\nStudents:");
  const firstNames = ["Aziz", "Dilnoza", "Sardor", "Kamola", "Bekzod", "Zarina", "Otabek", "Malika", "Jasur", "Nigora", "Farrukh", "Sitora"];
  const lastNames = ["Karimov", "Yusupova", "Tashkentov", "Ergasheva", "Rustamov", "Nazarova", "Abdullaev", "Ismoilova", "Saidov", "Xolova"];
  let studentCount = 0;
  for (let i = 0; i < 12; i++) {
    const groupId = groupIds[i % groupIds.length];
    const username = `student${i + 1}`;
    const id = await createUser({
      username,
      pin: "123456",
      role: "student",
      first_name: firstNames[i % firstNames.length]!,
      last_name: lastNames[i % lastNames.length]!,
      student_id: `S${String(1000 + i)}`,
      group_id: groupId,
      phone: `+99890${String(1000000 + i).slice(-7)}`,
    });
    if (id) studentCount += 1;
  }
  console.log(`  ${studentCount} students created`);

  console.log("\nSchedules:");
  let scheduleCount = 0;
  for (const groupId of groupIds) {
    for (let day = 1; day <= 5; day++) {
      const subjectId = subjectIds[day % subjectIds.length];
      const teacherId = teacherIds[day % teacherIds.length];
      const { error } = await supabase.from("schedules").insert({
        group_id: groupId,
        subject_id: subjectId,
        teacher_id: teacherId,
        room: `${200 + day}`,
        day_of_week: day,
        start_time: "09:00",
        end_time: "10:20",
      });
      if (!error) scheduleCount += 1;
    }
  }
  console.log(`  ${scheduleCount} schedule entries created`);

  console.log("\nSeed complete.");
  console.log("\nSign in with:");
  console.log("  admin / 123456");
  console.log("  leader.cs101 / 123456");
  console.log("  student1 / 123456");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
