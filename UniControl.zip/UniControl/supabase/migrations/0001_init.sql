-- ============================================================================
-- UniControl — Initial schema
-- Postgres / Supabase. Auth identities live in auth.users; profiles extends it.
-- ============================================================================

create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- ----------------------------------------------------------------------------
-- Enums
-- ----------------------------------------------------------------------------
create type user_role as enum ('admin', 'leader', 'student');
create type attendance_status as enum ('present', 'absent', 'late', 'excused');
create type attendance_session_status as enum ('scheduled', 'active', 'closed', 'cancelled');
create type verification_method as enum ('location_qr', 'location_only', 'manual');
create type assignment_status as enum ('pending', 'submitted', 'late', 'reviewed');
create type notification_target as enum ('everyone', 'all_leaders', 'all_students', 'group', 'student');
create type notification_type as enum ('info', 'success', 'warning', 'urgent');

-- ----------------------------------------------------------------------------
-- updated_at helper trigger
-- ----------------------------------------------------------------------------
create or replace function public.fn_set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ----------------------------------------------------------------------------
-- groups
-- ----------------------------------------------------------------------------
create table public.groups (
  id uuid primary key default gen_random_uuid(),
  group_name text not null,
  faculty text not null,
  course integer not null check (course between 1 and 8),
  year integer not null,
  description text,
  leader_id uuid, -- FK added after profiles is created
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (group_name)
);

create index idx_groups_faculty on public.groups (faculty);
create index idx_groups_course on public.groups (course);

create trigger trg_groups_updated_at before update on public.groups
  for each row execute function public.fn_set_updated_at();

-- ----------------------------------------------------------------------------
-- profiles (admin, leader, student identities — 1:1 with auth.users)
-- ----------------------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  role user_role not null,
  username text not null,
  first_name text not null,
  last_name text not null,
  phone text,
  email text,
  avatar_url text,
  student_id text, -- university student ID number, students only
  group_id uuid references public.groups (id) on delete set null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (username),
  unique (student_id)
);

create index idx_profiles_role on public.profiles (role);
create index idx_profiles_group_id on public.profiles (group_id);

create trigger trg_profiles_updated_at before update on public.profiles
  for each row execute function public.fn_set_updated_at();

alter table public.groups
  add constraint fk_groups_leader foreign key (leader_id) references public.profiles (id) on delete set null;

create index idx_groups_leader_id on public.groups (leader_id);

-- A leader profile must not reference a group other than the one that names them leader is
-- enforced at the application layer (server actions); DB keeps both directions consistent enough
-- for read access while avoiding a circular FK deadlock at table-creation time.

-- ----------------------------------------------------------------------------
-- subjects & teachers
-- ----------------------------------------------------------------------------
create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  created_at timestamptz not null default now()
);

create table public.teachers (
  id uuid primary key default gen_random_uuid(),
  first_name text not null,
  last_name text not null,
  phone text,
  email text,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- schedules
-- ----------------------------------------------------------------------------
create table public.schedules (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups (id) on delete cascade,
  subject_id uuid not null references public.subjects (id) on delete restrict,
  teacher_id uuid references public.teachers (id) on delete set null,
  room text not null,
  day_of_week smallint not null check (day_of_week between 0 and 6), -- 0=Sunday .. 6=Saturday
  start_time time not null,
  end_time time not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_time > start_time)
);

create index idx_schedules_group_id on public.schedules (group_id);
create index idx_schedules_day on public.schedules (day_of_week);

create trigger trg_schedules_updated_at before update on public.schedules
  for each row execute function public.fn_set_updated_at();

-- ----------------------------------------------------------------------------
-- university_settings (singleton configuration row)
-- ----------------------------------------------------------------------------
create table public.university_settings (
  id integer primary key default 1,
  university_name text not null default 'UniControl University',
  latitude double precision not null default 40.785444,
  longitude double precision not null default 72.352389,
  attendance_radius_m integer not null default 200,
  timezone text not null default 'Asia/Tashkent',
  qr_expiry_seconds integer not null default 45,
  late_after_minutes integer not null default 10,
  updated_at timestamptz not null default now(),
  constraint singleton_row check (id = 1),
  constraint valid_lat check (latitude between -90 and 90),
  constraint valid_lng check (longitude between -180 and 180),
  constraint valid_radius check (attendance_radius_m > 0 and attendance_radius_m <= 5000)
);

insert into public.university_settings (id) values (1);

create trigger trg_settings_updated_at before update on public.university_settings
  for each row execute function public.fn_set_updated_at();

-- ----------------------------------------------------------------------------
-- attendance_sessions
-- ----------------------------------------------------------------------------
create table public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.groups (id) on delete cascade,
  subject_id uuid not null references public.subjects (id) on delete restrict,
  teacher_id uuid references public.teachers (id) on delete set null,
  schedule_id uuid references public.schedules (id) on delete set null,
  session_date date not null default current_date,
  start_time timestamptz not null default now(),
  end_time timestamptz not null,
  status attendance_session_status not null default 'active',
  qr_token text not null default encode(gen_random_bytes(24), 'hex'),
  qr_expires_at timestamptz not null default (now() + interval '45 seconds'),
  created_by uuid not null references public.profiles (id),
  created_at timestamptz not null default now(),
  check (end_time > start_time)
);

create index idx_att_sessions_group on public.attendance_sessions (group_id);
create index idx_att_sessions_status on public.attendance_sessions (status);
create index idx_att_sessions_date on public.attendance_sessions (session_date);

-- ----------------------------------------------------------------------------
-- attendance_records
-- ----------------------------------------------------------------------------
create table public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles (id) on delete cascade,
  group_id uuid not null references public.groups (id) on delete cascade,
  subject_id uuid not null references public.subjects (id) on delete restrict,
  attendance_session_id uuid not null references public.attendance_sessions (id) on delete cascade,
  status attendance_status not null,
  latitude double precision,
  longitude double precision,
  location_accuracy double precision,
  distance_from_university double precision,
  verification_method verification_method not null default 'location_qr',
  checked_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  constraint chk_lat check (latitude is null or latitude between -90 and 90),
  constraint chk_lng check (longitude is null or longitude between -180 and 180),
  unique (student_id, attendance_session_id)
);

create index idx_att_records_student on public.attendance_records (student_id);
create index idx_att_records_session on public.attendance_records (attendance_session_id);
create index idx_att_records_group on public.attendance_records (group_id);
create index idx_att_records_checked_at on public.attendance_records (checked_at);

-- ----------------------------------------------------------------------------
-- assignments & submissions
-- ----------------------------------------------------------------------------
create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  group_id uuid not null references public.groups (id) on delete cascade,
  subject_id uuid not null references public.subjects (id) on delete restrict,
  deadline timestamptz not null,
  created_by uuid not null references public.profiles (id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_assignments_group on public.assignments (group_id);
create index idx_assignments_deadline on public.assignments (deadline);

create trigger trg_assignments_updated_at before update on public.assignments
  for each row execute function public.fn_set_updated_at();

create table public.assignment_submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments (id) on delete cascade,
  student_id uuid not null references public.profiles (id) on delete cascade,
  text_answer text,
  file_path text,
  status assignment_status not null default 'pending',
  grade numeric(5, 2),
  feedback text,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (assignment_id, student_id)
);

create index idx_submissions_assignment on public.assignment_submissions (assignment_id);
create index idx_submissions_student on public.assignment_submissions (student_id);

create trigger trg_submissions_updated_at before update on public.assignment_submissions
  for each row execute function public.fn_set_updated_at();

-- ----------------------------------------------------------------------------
-- notifications & reads
-- ----------------------------------------------------------------------------
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  type notification_type not null default 'info',
  sender_id uuid not null references public.profiles (id),
  target_type notification_target not null,
  target_id uuid, -- group id or student(profile) id, null for everyone/all_leaders/all_students
  created_at timestamptz not null default now()
);

create index idx_notifications_target on public.notifications (target_type, target_id);
create index idx_notifications_created_at on public.notifications (created_at desc);

create table public.notification_reads (
  id uuid primary key default gen_random_uuid(),
  notification_id uuid not null references public.notifications (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  read_at timestamptz not null default now(),
  unique (notification_id, user_id)
);

create index idx_notification_reads_user on public.notification_reads (user_id);

-- ----------------------------------------------------------------------------
-- audit_logs
-- ----------------------------------------------------------------------------
create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles (id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  old_data jsonb,
  new_data jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz not null default now()
);

create index idx_audit_logs_actor on public.audit_logs (actor_id);
create index idx_audit_logs_entity on public.audit_logs (entity_type, entity_id);
create index idx_audit_logs_created_at on public.audit_logs (created_at desc);

-- ============================================================================
-- Helper functions for RLS (SECURITY DEFINER to avoid recursive RLS on profiles)
-- ============================================================================
create or replace function public.current_role()
returns user_role
language sql
security definer
set search_path = public
stable
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.current_group_id()
returns uuid
language sql
security definer
set search_path = public
stable
as $$
  select group_id from public.profiles where id = auth.uid();
$$;

create or replace function public.is_active_user()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select coalesce((select is_active from public.profiles where id = auth.uid()), false);
$$;

create or replace function public.leads_group(target_group_id uuid)
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.groups g
    where g.id = target_group_id and g.leader_id = auth.uid()
  );
$$;

-- ============================================================================
-- Haversine distance in meters between two lat/lng points
-- ============================================================================
create or replace function public.fn_haversine_meters(
  lat1 double precision, lng1 double precision,
  lat2 double precision, lng2 double precision
)
returns double precision
language plpgsql
immutable
as $$
declare
  r double precision := 6371000; -- Earth radius in meters
  phi1 double precision := radians(lat1);
  phi2 double precision := radians(lat2);
  d_phi double precision := radians(lat2 - lat1);
  d_lambda double precision := radians(lng2 - lng1);
  a double precision;
  c double precision;
begin
  a := sin(d_phi / 2) ^ 2 + cos(phi1) * cos(phi2) * sin(d_lambda / 2) ^ 2;
  c := 2 * atan2(sqrt(a), sqrt(1 - a));
  return r * c;
end;
$$;

-- ============================================================================
-- SECURITY DEFINER RPC: submit attendance (all validation happens server-side,
-- inside the database, regardless of which client calls it)
-- ============================================================================
create or replace function public.fn_submit_attendance(
  p_session_id uuid,
  p_qr_token text,
  p_latitude double precision,
  p_longitude double precision,
  p_accuracy double precision
)
returns table (
  ok boolean,
  status attendance_status,
  message text,
  distance_m double precision
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_role user_role;
  v_active boolean;
  v_group_id uuid;
  v_session record;
  v_settings record;
  v_distance double precision;
  v_final_status attendance_status;
  v_already_exists boolean;
begin
  if v_uid is null then
    return query select false, null::attendance_status, 'Not authenticated.', null::double precision;
    return;
  end if;

  select role, is_active, group_id into v_role, v_active, v_group_id
  from public.profiles where id = v_uid;

  if v_role is null or v_role <> 'student' then
    return query select false, null::attendance_status, 'Only students can submit attendance.', null::double precision;
    return;
  end if;

  if not v_active then
    return query select false, null::attendance_status, 'Your account is inactive.', null::double precision;
    return;
  end if;

  if v_group_id is null then
    return query select false, null::attendance_status, 'You are not assigned to a group.', null::double precision;
    return;
  end if;

  select * into v_session from public.attendance_sessions where id = p_session_id for update;

  if v_session is null then
    return query select false, null::attendance_status, 'Attendance session not found.', null::double precision;
    return;
  end if;

  if v_session.group_id <> v_group_id then
    return query select false, null::attendance_status, 'This session does not belong to your group.', null::double precision;
    return;
  end if;

  if v_session.status <> 'active' then
    return query select false, null::attendance_status, 'This attendance session is not active.', null::double precision;
    return;
  end if;

  if now() < v_session.start_time or now() > v_session.end_time then
    return query select false, null::attendance_status, 'The attendance window is closed.', null::double precision;
    return;
  end if;

  if p_qr_token is null or p_qr_token <> v_session.qr_token then
    return query select false, null::attendance_status, 'Invalid QR code. Please rescan.', null::double precision;
    return;
  end if;

  if now() > v_session.qr_expires_at then
    return query select false, null::attendance_status, 'QR code has expired. Please rescan.', null::double precision;
    return;
  end if;

  if p_latitude is null or p_longitude is null then
    return query select false, null::attendance_status, 'Location is required.', null::double precision;
    return;
  end if;

  if p_latitude < -90 or p_latitude > 90 or p_longitude < -180 or p_longitude > 180 then
    return query select false, null::attendance_status, 'Invalid coordinates.', null::double precision;
    return;
  end if;

  if p_accuracy is not null and p_accuracy > 100 then
    return query select false, null::attendance_status, 'Location accuracy is too low. Move to an open area and try again.', null::double precision;
    return;
  end if;

  select exists(
    select 1 from public.attendance_records
    where student_id = v_uid and attendance_session_id = p_session_id
  ) into v_already_exists;

  if v_already_exists then
    return query select false, null::attendance_status, 'Attendance already submitted for this session.', null::double precision;
    return;
  end if;

  select * into v_settings from public.university_settings where id = 1;

  v_distance := public.fn_haversine_meters(p_latitude, p_longitude, v_settings.latitude, v_settings.longitude);

  -- Borderline accuracy: if the reported distance minus the GPS accuracy margin
  -- could still be within radius, but the reported distance itself is outside,
  -- reject conservatively rather than trusting an imprecise reading.
  if v_distance > v_settings.attendance_radius_m then
    return query select false, null::attendance_status, 'You are outside the university attendance zone.', v_distance;
    return;
  end if;

  v_final_status := case
    when now() > (v_session.start_time + make_interval(mins => v_settings.late_after_minutes)) then 'late'
    else 'present'
  end;

  insert into public.attendance_records (
    student_id, group_id, subject_id, attendance_session_id, status,
    latitude, longitude, location_accuracy, distance_from_university, verification_method
  ) values (
    v_uid, v_group_id, v_session.subject_id, p_session_id, v_final_status,
    p_latitude, p_longitude, p_accuracy, v_distance, 'location_qr'
  );

  return query select true, v_final_status, 'Attendance recorded.', v_distance;
end;
$$;

revoke all on function public.fn_submit_attendance from public;
grant execute on function public.fn_submit_attendance to authenticated;

-- ============================================================================
-- RPC: rotate QR token for an active session (admin/leader of that group only)
-- ============================================================================
create or replace function public.fn_rotate_qr(p_session_id uuid, p_ttl_seconds integer default null)
returns table (qr_token text, qr_expires_at timestamptz)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role user_role := public.current_role();
  v_group_id uuid;
  v_ttl integer;
  v_new_token text;
  v_new_expiry timestamptz;
begin
  select s.group_id into v_group_id from public.attendance_sessions s where s.id = p_session_id;

  if v_group_id is null then
    raise exception 'Session not found';
  end if;

  if v_role = 'admin' then
    null;
  elsif v_role = 'leader' and public.leads_group(v_group_id) then
    null;
  else
    raise exception 'Not authorized to rotate this session QR code';
  end if;

  select coalesce(p_ttl_seconds, qr_expiry_seconds) into v_ttl from public.university_settings where id = 1;
  v_new_token := encode(gen_random_bytes(24), 'hex');
  v_new_expiry := now() + make_interval(secs => v_ttl);

  update public.attendance_sessions
  set qr_token = v_new_token, qr_expires_at = v_new_expiry
  where id = p_session_id;

  return query select v_new_token, v_new_expiry;
end;
$$;

revoke all on function public.fn_rotate_qr from public;
grant execute on function public.fn_rotate_qr to authenticated;

-- ============================================================================
-- RPC: accurate unread notification count for the current user
-- ============================================================================
create or replace function public.fn_unread_notification_count()
returns integer
language sql
security definer
set search_path = public
stable
as $$
  select count(*)::integer
  from public.notifications n
  where (
    n.target_type = 'everyone'
    or (n.target_type = 'all_leaders' and public.current_role() = 'leader')
    or (n.target_type = 'all_students' and public.current_role() = 'student')
    or (n.target_type = 'group' and n.target_id = public.current_group_id())
    or (n.target_type = 'student' and n.target_id = auth.uid())
  )
  and not exists (
    select 1 from public.notification_reads r
    where r.notification_id = n.id and r.user_id = auth.uid()
  );
$$;

revoke all on function public.fn_unread_notification_count from public;
grant execute on function public.fn_unread_notification_count to authenticated;

-- ============================================================================
-- RPC: assign / unassign a group leader (keeps groups.leader_id and the
-- leader's profiles.group_id in sync atomically — admin only)
-- ============================================================================
create or replace function public.fn_assign_leader(p_group_id uuid, p_leader_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_previous_leader uuid;
  v_leader_role user_role;
begin
  if public.current_role() <> 'admin' then
    raise exception 'Only admins can assign group leaders';
  end if;

  select role into v_leader_role from public.profiles where id = p_leader_id;
  if v_leader_role is distinct from 'leader' then
    raise exception 'Target user is not a leader';
  end if;

  select leader_id into v_previous_leader from public.groups where id = p_group_id;

  if v_previous_leader is not null and v_previous_leader <> p_leader_id then
    update public.profiles set group_id = null where id = v_previous_leader and role = 'leader';
  end if;

  update public.groups set leader_id = p_leader_id where id = p_group_id;
  update public.profiles set group_id = p_group_id where id = p_leader_id;
end;
$$;

revoke all on function public.fn_assign_leader from public;
grant execute on function public.fn_assign_leader to authenticated;

create or replace function public.fn_unassign_leader(p_group_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_leader_id uuid;
begin
  if public.current_role() <> 'admin' then
    raise exception 'Only admins can remove group leaders';
  end if;

  select leader_id into v_leader_id from public.groups where id = p_group_id;

  update public.groups set leader_id = null where id = p_group_id;

  if v_leader_id is not null then
    update public.profiles set group_id = null where id = v_leader_id and role = 'leader';
  end if;
end;
$$;

revoke all on function public.fn_unassign_leader from public;
grant execute on function public.fn_unassign_leader to authenticated;

-- ============================================================================
-- RPC: admin dashboard stats — every number is computed live from real rows
-- ============================================================================
create or replace function public.fn_admin_dashboard_stats()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_total_students integer;
  v_total_groups integer;
  v_total_leaders integer;
  v_today_present integer;
  v_today_late integer;
  v_today_excused integer;
  v_today_absent integer;
  v_active_assignments integer;
  v_unread_notifications integer;
begin
  if public.current_role() <> 'admin' then
    raise exception 'Only admins can view dashboard stats';
  end if;

  select count(*) into v_total_students from public.profiles where role = 'student';
  select count(*) into v_total_groups from public.groups;
  select count(*) into v_total_leaders from public.profiles where role = 'leader';

  select
    count(*) filter (where status = 'present'),
    count(*) filter (where status = 'late'),
    count(*) filter (where status = 'excused')
  into v_today_present, v_today_late, v_today_excused
  from public.attendance_records
  where checked_at::date = current_date;

  select coalesce(sum(greatest(member_counts.member_count - coalesce(checked_in.record_count, 0), 0)), 0)
  into v_today_absent
  from public.attendance_sessions s
  join (
    select group_id, count(*) as member_count
    from public.profiles
    where role = 'student' and is_active = true
    group by group_id
  ) member_counts on member_counts.group_id = s.group_id
  left join (
    select attendance_session_id, count(*) as record_count
    from public.attendance_records
    group by attendance_session_id
  ) checked_in on checked_in.attendance_session_id = s.id
  where s.session_date = current_date and s.end_time < now();

  select count(*) into v_active_assignments from public.assignments where deadline > now();

  select public.fn_unread_notification_count() into v_unread_notifications;

  return jsonb_build_object(
    'total_students', v_total_students,
    'total_groups', v_total_groups,
    'total_leaders', v_total_leaders,
    'today_present', v_today_present,
    'today_late', v_today_late,
    'today_excused', v_today_excused,
    'today_absent', v_today_absent,
    'active_assignments', v_active_assignments,
    'unread_notifications', v_unread_notifications
  );
end;
$$;

revoke all on function public.fn_admin_dashboard_stats from public;
grant execute on function public.fn_admin_dashboard_stats to authenticated;

-- ============================================================================
-- RPC: attendance trend for the last N days (admin dashboard chart)
-- ============================================================================
create or replace function public.fn_attendance_trend(p_days integer default 14)
returns table (day date, present bigint, late bigint, absent bigint, excused bigint)
language sql
security definer
set search_path = public
stable
as $$
  select
    d::date as day,
    coalesce(sum((r.status = 'present')::int), 0) as present,
    coalesce(sum((r.status = 'late')::int), 0) as late,
    0::bigint as absent,
    coalesce(sum((r.status = 'excused')::int), 0) as excused
  from generate_series(current_date - (greatest(p_days, 1) - 1), current_date, interval '1 day') d
  left join public.attendance_records r on r.checked_at::date = d::date
  where public.current_role() = 'admin'
  group by d
  order by d;
$$;

revoke all on function public.fn_attendance_trend from public;
grant execute on function public.fn_attendance_trend to authenticated;

-- ============================================================================
-- RPC: close an attendance session early and backfill 'absent' records for
-- every active student in the group who never checked in.
-- ============================================================================
create or replace function public.fn_close_attendance_session(p_session_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_session record;
  v_role user_role := public.current_role();
begin
  select * into v_session from public.attendance_sessions where id = p_session_id for update;
  if v_session is null then
    raise exception 'Session not found';
  end if;

  if v_role = 'admin' then
    null;
  elsif v_role = 'leader' and public.leads_group(v_session.group_id) then
    null;
  else
    raise exception 'Not authorized to close this session';
  end if;

  update public.attendance_sessions
  set status = 'closed', end_time = least(end_time, now())
  where id = p_session_id;

  insert into public.attendance_records (student_id, group_id, subject_id, attendance_session_id, status, verification_method)
  select p.id, v_session.group_id, v_session.subject_id, p_session_id, 'absent', 'manual'
  from public.profiles p
  where p.role = 'student' and p.is_active = true and p.group_id = v_session.group_id
    and not exists (
      select 1 from public.attendance_records r
      where r.attendance_session_id = p_session_id and r.student_id = p.id
    );
end;
$$;

revoke all on function public.fn_close_attendance_session from public;
grant execute on function public.fn_close_attendance_session to authenticated;

-- ============================================================================
-- RPC: leader dashboard stats, scoped to the leader's own group only
-- ============================================================================
create or replace function public.fn_leader_dashboard_stats()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_group_id uuid;
  v_total_students integer;
  v_today_present integer;
  v_today_late integer;
  v_today_excused integer;
  v_today_absent integer;
  v_active_assignments integer;
  v_unread_notifications integer;
begin
  if public.current_role() <> 'leader' then
    raise exception 'Only leaders can view this';
  end if;

  v_group_id := public.current_group_id();
  if v_group_id is null then
    return jsonb_build_object(
      'total_students', 0, 'today_present', 0, 'today_late', 0, 'today_excused', 0,
      'today_absent', 0, 'active_assignments', 0, 'unread_notifications', 0
    );
  end if;

  select count(*) into v_total_students from public.profiles where role = 'student' and group_id = v_group_id;

  select
    count(*) filter (where status = 'present'),
    count(*) filter (where status = 'late'),
    count(*) filter (where status = 'excused')
  into v_today_present, v_today_late, v_today_excused
  from public.attendance_records
  where group_id = v_group_id and checked_at::date = current_date;

  select coalesce(sum(greatest(v_total_students - coalesce(checked_in.record_count, 0), 0)), 0)
  into v_today_absent
  from public.attendance_sessions s
  left join (
    select attendance_session_id, count(*) as record_count
    from public.attendance_records
    where group_id = v_group_id
    group by attendance_session_id
  ) checked_in on checked_in.attendance_session_id = s.id
  where s.group_id = v_group_id and s.session_date = current_date and s.end_time < now();

  select count(*) into v_active_assignments from public.assignments where group_id = v_group_id and deadline > now();
  select public.fn_unread_notification_count() into v_unread_notifications;

  return jsonb_build_object(
    'total_students', v_total_students,
    'today_present', v_today_present,
    'today_late', v_today_late,
    'today_excused', v_today_excused,
    'today_absent', v_today_absent,
    'active_assignments', v_active_assignments,
    'unread_notifications', v_unread_notifications
  );
end;
$$;

revoke all on function public.fn_leader_dashboard_stats from public;
grant execute on function public.fn_leader_dashboard_stats to authenticated;

-- ============================================================================
-- Row Level Security
-- ============================================================================
alter table public.groups enable row level security;
alter table public.profiles enable row level security;
alter table public.subjects enable row level security;
alter table public.teachers enable row level security;
alter table public.schedules enable row level security;
alter table public.university_settings enable row level security;
alter table public.attendance_sessions enable row level security;
alter table public.attendance_records enable row level security;
alter table public.assignments enable row level security;
alter table public.assignment_submissions enable row level security;
alter table public.notifications enable row level security;
alter table public.notification_reads enable row level security;
alter table public.audit_logs enable row level security;

-- profiles ---------------------------------------------------------------
create policy profiles_select_own on public.profiles for select
  using (id = auth.uid());

create policy profiles_select_admin on public.profiles for select
  using (public.current_role() = 'admin');

create policy profiles_select_leader_group on public.profiles for select
  using (public.current_role() = 'leader' and group_id = public.current_group_id());

create policy profiles_select_student_peers on public.profiles for select
  using (public.current_role() = 'student' and group_id = public.current_group_id());

create policy profiles_insert_admin on public.profiles for insert
  with check (public.current_role() = 'admin');

create policy profiles_insert_leader_student on public.profiles for insert
  with check (public.current_role() = 'leader' and role = 'student' and group_id = public.current_group_id());

create policy profiles_update_admin on public.profiles for update
  using (public.current_role() = 'admin');

create policy profiles_update_self on public.profiles for update
  using (id = auth.uid());

create policy profiles_update_leader_student on public.profiles for update
  using (public.current_role() = 'leader' and role = 'student' and group_id = public.current_group_id());

create policy profiles_delete_admin on public.profiles for delete
  using (public.current_role() = 'admin');

-- groups -------------------------------------------------------------------
create policy groups_select_admin on public.groups for select
  using (public.current_role() = 'admin');

create policy groups_select_member on public.groups for select
  using (id = public.current_group_id() or leader_id = auth.uid());

create policy groups_insert_admin on public.groups for insert
  with check (public.current_role() = 'admin');

create policy groups_update_admin on public.groups for update
  using (public.current_role() = 'admin');

create policy groups_delete_admin on public.groups for delete
  using (public.current_role() = 'admin');

-- subjects / teachers --------------------------------------------------------
create policy subjects_select_all on public.subjects for select using (public.is_active_user());
create policy subjects_write_admin on public.subjects for insert with check (public.current_role() = 'admin');
create policy subjects_update_admin on public.subjects for update using (public.current_role() = 'admin');
create policy subjects_delete_admin on public.subjects for delete using (public.current_role() = 'admin');

create policy teachers_select_all on public.teachers for select using (public.is_active_user());
create policy teachers_write_admin on public.teachers for insert with check (public.current_role() = 'admin');
create policy teachers_update_admin on public.teachers for update using (public.current_role() = 'admin');
create policy teachers_delete_admin on public.teachers for delete using (public.current_role() = 'admin');

-- schedules -------------------------------------------------------------------
create policy schedules_select_admin on public.schedules for select using (public.current_role() = 'admin');
create policy schedules_select_member on public.schedules for select using (group_id = public.current_group_id());
create policy schedules_write_admin on public.schedules for insert with check (public.current_role() = 'admin');
create policy schedules_update_admin on public.schedules for update using (public.current_role() = 'admin');
create policy schedules_delete_admin on public.schedules for delete using (public.current_role() = 'admin');

-- university_settings ----------------------------------------------------------
create policy settings_select_all on public.university_settings for select using (public.is_active_user());
create policy settings_update_admin on public.university_settings for update using (public.current_role() = 'admin');

-- attendance_sessions ------------------------------------------------------------
create policy att_sessions_select_admin on public.attendance_sessions for select using (public.current_role() = 'admin');
create policy att_sessions_select_member on public.attendance_sessions for select using (group_id = public.current_group_id());
create policy att_sessions_insert_admin on public.attendance_sessions for insert with check (public.current_role() = 'admin');
create policy att_sessions_insert_leader on public.attendance_sessions for insert with check (public.current_role() = 'leader' and public.leads_group(group_id));
create policy att_sessions_update_admin on public.attendance_sessions for update using (public.current_role() = 'admin');
create policy att_sessions_update_leader on public.attendance_sessions for update using (public.current_role() = 'leader' and public.leads_group(group_id));
create policy att_sessions_delete_admin on public.attendance_sessions for delete using (public.current_role() = 'admin');

-- attendance_records ---------------------------------------------------------
-- Inserts only via fn_submit_attendance (SECURITY DEFINER); no direct insert policy for students.
create policy att_records_select_admin on public.attendance_records for select using (public.current_role() = 'admin');
create policy att_records_select_own on public.attendance_records for select using (student_id = auth.uid());
create policy att_records_select_leader on public.attendance_records for select using (public.current_role() = 'leader' and group_id = public.current_group_id());
create policy att_records_insert_admin on public.attendance_records for insert with check (public.current_role() = 'admin');
create policy att_records_insert_leader on public.attendance_records for insert with check (
  public.current_role() = 'leader'
  and public.leads_group(group_id)
  and exists (select 1 from public.profiles p where p.id = student_id and p.group_id = attendance_records.group_id)
);
create policy att_records_update_admin on public.attendance_records for update using (public.current_role() = 'admin');
create policy att_records_update_leader on public.attendance_records for update using (public.current_role() = 'leader' and group_id = public.current_group_id());

-- assignments ------------------------------------------------------------------
create policy assignments_select_admin on public.assignments for select using (public.current_role() = 'admin');
create policy assignments_select_member on public.assignments for select using (group_id = public.current_group_id());
create policy assignments_insert_admin on public.assignments for insert with check (public.current_role() = 'admin');
create policy assignments_insert_leader on public.assignments for insert with check (public.current_role() = 'leader' and public.leads_group(group_id));
create policy assignments_update_admin on public.assignments for update using (public.current_role() = 'admin');
create policy assignments_update_leader on public.assignments for update using (public.current_role() = 'leader' and public.leads_group(group_id));
create policy assignments_delete_admin on public.assignments for delete using (public.current_role() = 'admin');
create policy assignments_delete_leader on public.assignments for delete using (public.current_role() = 'leader' and public.leads_group(group_id));

-- assignment_submissions --------------------------------------------------------
create policy submissions_select_admin on public.assignment_submissions for select using (public.current_role() = 'admin');
create policy submissions_select_own on public.assignment_submissions for select using (student_id = auth.uid());
create policy submissions_select_leader on public.assignment_submissions for select using (
  public.current_role() = 'leader' and exists (
    select 1 from public.assignments a where a.id = assignment_id and public.leads_group(a.group_id)
  )
);
create policy submissions_insert_own on public.assignment_submissions for insert with check (student_id = auth.uid());
create policy submissions_update_own on public.assignment_submissions for update using (
  student_id = auth.uid() and status in ('pending', 'submitted', 'late')
);
create policy submissions_update_admin on public.assignment_submissions for update using (public.current_role() = 'admin');
create policy submissions_update_leader on public.assignment_submissions for update using (
  public.current_role() = 'leader' and exists (
    select 1 from public.assignments a where a.id = assignment_id and public.leads_group(a.group_id)
  )
);

-- notifications -----------------------------------------------------------------
create policy notifications_select_admin on public.notifications for select using (public.current_role() = 'admin');
create policy notifications_select_visible on public.notifications for select using (
  target_type = 'everyone'
  or (target_type = 'all_leaders' and public.current_role() = 'leader')
  or (target_type = 'all_students' and public.current_role() = 'student')
  or (target_type = 'group' and target_id = public.current_group_id())
  or (target_type = 'student' and target_id = auth.uid())
  or sender_id = auth.uid()
);
create policy notifications_insert_admin on public.notifications for insert with check (public.current_role() = 'admin');
create policy notifications_insert_leader on public.notifications for insert with check (
  public.current_role() = 'leader'
  and target_type in ('group', 'student')
  and (
    (target_type = 'group' and target_id = public.current_group_id())
    or (target_type = 'student' and exists (select 1 from public.profiles p where p.id = target_id and p.group_id = public.current_group_id()))
  )
);
create policy notifications_delete_admin on public.notifications for delete using (public.current_role() = 'admin');

-- notification_reads -------------------------------------------------------------
create policy notif_reads_select_own on public.notification_reads for select using (user_id = auth.uid());
create policy notif_reads_insert_own on public.notification_reads for insert with check (user_id = auth.uid());

-- audit_logs ----------------------------------------------------------------------
create policy audit_logs_select_admin on public.audit_logs for select using (public.current_role() = 'admin');
create policy audit_logs_insert_authenticated on public.audit_logs for insert with check (auth.uid() is not null);

-- ============================================================================
-- Storage: assignment submissions (private bucket)
-- Object path convention: {assignment_id}/{student_id}/{filename}
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('assignment-submissions', 'assignment-submissions', false)
on conflict (id) do nothing;

create policy "submissions_storage_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'assignment-submissions' and (storage.foldername(name))[2] = auth.uid()::text);

create policy "submissions_storage_select_own" on storage.objects for select to authenticated
  using (bucket_id = 'assignment-submissions' and (storage.foldername(name))[2] = auth.uid()::text);

create policy "submissions_storage_update_own" on storage.objects for update to authenticated
  using (bucket_id = 'assignment-submissions' and (storage.foldername(name))[2] = auth.uid()::text);

create policy "submissions_storage_delete_own" on storage.objects for delete to authenticated
  using (bucket_id = 'assignment-submissions' and (storage.foldername(name))[2] = auth.uid()::text);

create policy "submissions_storage_select_admin" on storage.objects for select to authenticated
  using (bucket_id = 'assignment-submissions' and public.current_role() = 'admin');

create policy "submissions_storage_select_leader" on storage.objects for select to authenticated
  using (
    bucket_id = 'assignment-submissions'
    and exists (
      select 1 from public.assignments a
      where a.id::text = (storage.foldername(name))[1] and public.leads_group(a.group_id)
    )
  );

-- ============================================================================
-- Storage: profile avatars (public read, owner-only write)
-- Object path convention: {user_id}/{filename}
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

create policy "avatars_storage_public_read" on storage.objects for select
  using (bucket_id = 'avatars');

create policy "avatars_storage_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "avatars_storage_update_own" on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "avatars_storage_delete_own" on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
